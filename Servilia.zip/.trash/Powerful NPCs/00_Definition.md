Definition

25 November 2022

14:31

 

Strong NPCs, classified by main D&D as legendary encounter.
