
###### Think Tank
a aquarium connected to a computer, the fishies calculate 
###### Rhombus
A black and infinitely smooth rhombus with a cylindrical inset on one of the equatorial points.
*~~No man's sky Atlas interface.~~*
