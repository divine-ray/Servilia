# #TODO 

basically the faceless now inhibiting Tombstone were somehow affiliated to the immense pool of knowledge that the archive of old (thylyist + lavish) is/was
this made them capable of producing the [[OA-WS Model 7ⁿ]] amongst other now-legendary arms and tools

i'm thinking of descendants of lavish pseudoneo or independent humanoids that somehow got into relations with lavish, and refined their tech for bipedal, land use


after their Fall (link here) the undead ghetto sepulchre got created, carved into the extensive cave system beneath the ninth forest 
the undead are NOT related to Tombstone or the faceless or any of that, they just took the place


though i would claim that the two hangmen are likely citizens of tombstone who got executed in the political instabilities prior to the fall 


