#### [[Utuw]]
K-Main sequence, habitable zone 0.1228 AU - 0.1771 AU
@0.7 solar masses + 0.8× solar radius, 40,856 bil years old

### #Schi 
- 0.13AU earthlike ringed inhabited
- [[Opar]]
	- desolate rocky (moon)
- [[Kynoly]]
	- volcanic, heated, captured protoplanet
- [[Heaugi]]
	- icy, frozen, cold
### [[Sphill]]
- 0,66AU large rocky atmosphere less
- 55 moons
	- evenly spaced around the planet
### [[Scheties]]
- 11,23AU   gas dwarf 
- [[Dirius]]
	- rocky grey not cratered 
- [[Degois]]
- [[Darb]]
~~-------~~
- 11 proto planets
	Eldritch god put a fart cloud
- 45 significant asteroids 
	- Shoemaker Levy
- 3 significant comets
	- Siblings to three moons of #Schi:
		1. Parop
		2. Shifty
		3. Herguami

One moon per significant civilisation?
Thrre moons, three comets, 

Utuw has rather harsh solar emissions and CMEs

	[Star name: Star type: Age: Mass: Radius: he Utuw System Star Stats Utuw K-Type Main Sequence (Yellow-Orange) 40,856 million years old 0.7 Solar masses (Sun --- I Solar mass) 0.8 x Sun\'s radius Utuw\'s Habitable Zone (The area where planets are neither too hot or too cold for liquid water to be present on the surface) Inner Edge: Outer Edge: Width: 0.1 AU 0.97 AU 0.87 AU Planet Distance from Utuw in AU BOLD planets are within the Habitable Zone. Red planets are inside the inner edge and may be molten or simply too hot for liquid water to exist, while Blue planets are outside the outer edge may be frozen or too cold.) Distance: (For reference, Earth is 1.0 AU) Total Planets: 3 Schi - (0.13 AU) Sphill - (0.66 AU) Kynoly - (Il .23 AU) Proto Planets: 11 Other Objects: Significant Asteroids: 45 System Facts: Significant Comets: 3 T he closest neighbouring star is 7 light years away. Earth-like Planet s chi Schi has multiple rings. Large Rocky Planet s phill Sphill has 55 moons. Gas Dwarf K ynoly Kynoly does not rotate. ](media/image1.jpeg)