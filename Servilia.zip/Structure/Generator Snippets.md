# Towns and Cities
## Locations
- Greenhome: A two-storey stone-walled building which has been completely overgrown by flowering vines, with scale-like leaves and thorny, writhing branches. It is the home of Nina, a young green dragon and sage.
> - The Clockwork: A large sphere of rotating gears and ticking escapements, crafted from brass and inscribed with glowing runes. No-one seems to know who created it, nor when, nor its purpose.
	- THIS FOR CITADEL OF GEAR
- The Earth Shrine: A wondrous monolith of precious stone, said to hold the ruby heart of the world.
- The ruins of a seven-sided tower, which appears restored upon the night of the new moon.

-  The Cats' Scriptorium: A large scribe's workshop, served by a clowder of cats. The cats usually divide their time between playing, sleeping, and working on the pages of a book of omens and portents. If asked by a wizard, they may produce a magical scroll of summoning, but no more often than once per month.
- The Dragon Pottery: The workshop of a female dwarf potter named Gela, built within a large dragon kiln. Gela spends several months filling the shop with thrown pots, then bricks in the door and spends several days firing it. The opening of the fired kiln is a local festival.

>The Gallows Tree: A long-dead ironwood tree, said to be haunted by the ghosts of the thieves and murderers which once hung from it.
>	THIS FOR THE TWO HANGMEN

>- The Inn of a Thousand Names: An elegant dwarven inn, which is said to have a thousand doors in a thousand towns, each under a different sign and name. Anyone who enters through a particular door can only leave through that same door, unless they know the innkeeper's secret.
>	QUICKTRAVEL

-  The Pool of Radiance: A small pool of water, which glows with a flickering blue light. It is said to be haunted by a malevolent spirit, waiting for a worthy creature to possess. The local townsfolk avoid it.
- The Temple of Ariel, God of Plants: An impressive terraced building, decorated with carved friezes and golden inscriptions.
- The Shrine of Ilgad: A cauldron lamp enshrining the flame of Ilgad, God of the Sky, said to reveal visions to those who leave an offering.
- The Water Shrine: A wondrous arch of clear water, said to reveal visions to those who drink from it.
- James' Armaments: A neglected weaponsmith's workshop, built around a shrine of Manael, Goddess of War.

# Items
## Potions
- Oil of Nepalese Palm (Potion):
	This jelly-like oil can can cover a Medium or smaller creature, and
    takes 10 minutes to apply.  If a Tiny or larger creature touches
    the affected creature within the next 8 hours, the oil bursts into
    flames.  Each creature within a 5-foot radius must make a Dexterity
    saving throw.  A target takes 1d6 fire damage on a failed save, or
    half as much damage on a successful one.
    In any case, this awakens the affected creature.
- Storyteller's Potion (Potion): 
	After drinking this wispy potion, illusory images accompany your speech.
	You do not directly control the illusion, but the images are of creatures, objects, and places you describe, and act as you describe them to. 
	The images never move more than 5 feet away from you, and are purely visual. The effect lasts for as long as you concentrate on it, up to 10 minutes.
- Mummer's Potion (Wondrous Item):
    While wearing these white gloves, you can use an action to conjure tiny, invisible barriers of magical force, of the sort used by mummers for their theatre.  The effect lasts for as long as you concentrate on it, up to 10 minutes.  You can also use a reaction  to conjure a larger barrier to protect you, which gives you a +5 bonus to AC.  This ends the effect at the start of your next turn. The gloves can't be used this way again until the next dawn.
## Rods
Surveyor's Rod (Rod): 
	While holding this rod, you know the distance to any fixed landscape feature you can see, such as a tree, mountain, oasis, castle, island, etc.
## Wondrous Items
- Bucket of Armor (Wondrous Item): 
	This simple wooden bucket is filled with scraps of leather and metal, and weighs 20 pounds. While you carry it in one hand, your base AC becomes 13 + your Dexterity modifier.
- Rat Cart (Wondrous Item): 
	This sturdy wooden cart is supported by four over-sized treadwheels, each of which contains a magical rat. The cart can carry up to 2000 pounds of weight, and balances itself. It moves at a speed of 40 ft. for up to eight hours per day, but never between midnight and dawn. The cart follows your simple verbal commands to start, stop, turn, etc.
- Bag of Candle Holding (Wondrous Item):
    This bag can hold up to 500 pounds of
    candles, but weighs 15 pounds regardless
    of its contents.  Retrieving an item from the bag requires an action.

## Scrolls
Origami Messenger (Scroll):
    You can use an action to read this scroll, which causes it to fold
    itself into a tiny origami squid.  The object
    will fly to a destination and deliver a message, as though you had
    cast the spell Animal Messenger (phb 212).


## Rings and Baubles
- Symbiotic Ring (Ring, requires attunement):
    When you put on this carved bone ring, it becomes snug around your
    finger and turns the color of your blood.  While you are attuned to
    the ring, you gain 10 temporary hit points daily at dawn.

## Armor
Scale Mail of the Serpent (Armor, scale mail, requires attunement):
    While wearing this scale mail, you can use an action to speak its
    command word.  The armor transforms into a giant constrictor snake, with you still inside it. The creature acts on its own initiative count and follows your mental commands.
    The armor returns to its normal form when you use an action to speak the command word again, or if the creature is reduced to 0 hit points.  The armor can't be used this way again until the next dawn.

## Tomes
Gane's Parchments of Shadows:
	a heavy libram bound in stained glass plates. It is sealed by fate, and can be opened only within the Court of Storms.
The Celestial Compendium of Sega:
	an impressive tome bound in iron plates set with deep green spinel. It was written by the wizards and sages of the Athenaeum of Sorcery.
Epos' Manuscripts:
	an impressive libram written in golden ink. A list of dates, both past and future, has been added in the middle of the tome.
The Elvos Incunabulum
	a compendium bound in copper plates set with deep green spinel. It is locked by magic, and can be opened only by starlight. -> [[Lunatics]]

#  Prophecies and Scriptures
## Prophecies
- In the Valley of Crystal, when the light comes to lifeless eyes, the Lantern of Strength shall be lost
- 