#Undead 

A plague, which swept the lands of Servilia. 
Caused by [[Schi ut-Pula]]'s depression.

It infects most if not all sentient beings, but mostly humanoids have been observed to succumb to it. 
'Infected' people do not die in the traditional sense. Their body ceases to function in terms of metabolism and other otherwise deemed-essential biological processes, but the psyche remains functional and in control of the motive apparatus. 

However, the mentality is prone to drastic changes under certain circumstances.
If the subject looses motivation or desire to strive on living or a purpose in their life, the lack of orientation will rapidly tear at their psyche and eventually leave them [[Hollowed]].
This state is akin to dementia or Alzheimer's and other neurodegenerative ilnesses, as it'll leave the individual personality torn apart and left to shreds, typically resulting in violent outbursts and disability to interact in reason with others.