Excerpt One
	We are the Children. The Children of the Flame. 
	The Flame...
	Must live on.
	How do we know? The heat tells us. The Heart... A being, a deity beyond, has sacrificed its core, for us, so that we spread the word, the heat. burn. BURN. **BURN THEM ALL.**
>First Spark, First Book of Cinders, First Blaze
###### *Preamble:*
That is our desire, our goal. Everyone, everything, consumed by the flame. Our history rests within fumes of smoke, but you are capable of dividing the fumes. 

In the Beginning, there was nothing. A barren land, bearing the marks of a-many decayed and forgotten. Then, the Spark arrived. It lit up the lands, laying waste to those who opposed it. The cinders fell into the fertile seed, and rose. The roaring flames fell silent, as if they were to listen to the seed.
It grew. 