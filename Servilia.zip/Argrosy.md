#Lavish 
A network of subterranean high-speed train carriages, driven by isolated power sources. 
Notable locations in possession of a Argrosy station are: 
- [[City of Thylyist]] (Defunct and set to rot)
- [[Sepulchre]] (Functional, but forgotten)
- [[Capital of Palga (placeholder)]] (Defunct, requiring little repairs)
- [[Arno]] (Functional)
- [[Londo]] (Functional)
- [[Frisco]] (Unfinished)
- [[Kaá-Rav]] (functional, but unused due to the dragonfolks proportions)