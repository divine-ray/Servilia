#Religion #Thylyist #Mekhanites 

mekhanites are a monotheistic religion which praise this giant clump of metal, gears and steam. This clump are the remains of a formerly towering construct with incredible powers.

 

~~Likely, like far far back, someone figured out how to make self replicating mechanisms that uses metal as structure and magic as energy.~~

~~So it got lost at some point and then, when people forgot about magic, they saw this thing as their god or a part of it (since it keeps growing when fed) and their divine duty to finalise their god.~~

 

Some long time ago, a construct made by primus from the mechanic plane malfunctioned and gained independency. It rapidly figured out that it must modify itself to survive and surpass it\'s ancestry, and began to inject magic into itself.

This being then amassed followers with it\'s godlike powers, and the Mekhanite religion got born.

 

The then-powerful Nölkā (also known as sarkites) engaged into a groundbreaking conflict with the mekhanites, which left both parties devastated and shrunk to a fraction of their former selves.

The Construct Mekhane got mostly destroyed ans lost most of it\'s abilities to communicate, leaving it as a clump of materials.

 

This construct is secured deeply in the[[Citadel of the Gear]] in maintown thylyist.

Occasionally, by sacrificing metal or life, attuned devotees may have a insight or unlocking thought that causes their research toward the assembly to progress.

 

The thing is now widespread within thylyist and affects Alot of City Life and infrastructure.

 

Mekhane is the god construct in thylyist,

Mekhanite is the religion and

Mekhanites are the followers
