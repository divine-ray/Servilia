#Cult #Religion 

Worshippers and self-proclaimed 'ambassadors' of [[The Void]], founded by High[[Warlock Gaíz-an]].

	They strive to bring over the void into the material plane, allowing the void to unleash its powers.

The count of members is unknown; estimated to 150 devoted followers and about 300 individuals who occasionally attend their meetings.

They operate in high stealth and secrecy.

Enduring the cruel path of becoming hollow and converting to a vessel is their most valued act, and is only reserved to those whom are deemed worthy.


### **Organisation: Oblivion Lodge**
*Description; structure; members; noteworthy history*

The Oblivion Lodge is a small, but powerful cult of magical people, who fight to end all life on our world. The Lodge has never been discovered by any non-cult members.

 
 ##### ***Motto:***
 From Void we came, to Void we return.
 #### ***Creed***
-   *Being alive is foul. Being dead is heresy.*
-   *The Void and its Agents is the true ruling power.*
- *The path of a Hollow is the highest virtue.*

 #### ***Goals***
 Assemble Masks. Create suitable vessels. Worship the void and allow it to flow through yourself. Do not attract attention. Remain unseen at all times. Assist the void in it's conquest.
 
  #### ***Typical Tasks***
  -   Retrieve Mask fragments
 -   Hollow out a Curse Bearer
