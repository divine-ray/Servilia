#Lunatics #Regions #Faction 

 

The deranged and off brand sorcerers residing in Stargard.

Capable of teaching the party the magic of the stars, ~~star signals~~ if they can understand them (must know ancient, celestial and draconic) and are resilient to the memetic corruption they give off

 
