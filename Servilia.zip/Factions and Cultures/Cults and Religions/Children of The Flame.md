#Children-of-the-Flame #Cult 
 

The children of the flame, worshippers of that one ever burning flame feeding on sacrificed Amarisk

(precisely the burst of Amarisk released on death)

The bodies or physical appearance of the higher up cultists get slowly undergoes pyrolysis into a animate figure of ashes.

 

> The CoTF caused the Blaze, the process of entities becoming Ashen.
>
>  
>
> Something something the flame burns them until they're ashes

 

A sign of progressing cremation is the loss of a functional endoskeleton, which usually is "celebrated" by a full 360° turn of the head.

 

Ashen ones are quite allergic and disliking towards water since it screws up their entire body and shape.

Archenemy towards [[The Cold]].

The only faction capable of producing [[Bottled Embers]], [[Splinter of Blazes]] and [[Bottled Smoulders]].