The #Twilight


Weird ethereal plane made of Amarisk, sentient, and physically accessible through magic or [[Fountainhead]].

Holds a infinite wrath upon the lavish, who constructed the FH, as they severely injured it and forced that wound open. using the Fountainhead.

All layers mimic a copy of our world, which gradually deteriorates into whats called [[The Void]].

Is constructed of 7 layers; each of which is a own plane of reality.
The red lines indicate the "floors", and mark the space Between.

The entire chaos caused by the dysfunctional FH is the Between being released uncontrolledly, and the twilight itself is indirectly amplifying the power of Between.

