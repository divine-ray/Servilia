#Heart-of-Cold ; synonymous to #The-Cold


It's a semiamorphous organism residing in the [[Northern Reaches]] of the Realm, especially the Poles.

It feeds upon [[Twilight]] and Amarisk residues, and thermal energy.



Archenemy towards the [[Children of The Flame]]

 

It's main way of existing is to convert any matter into its own tissue, which is necrotic and frozen: [[Premature Heart of Cold]]

Small patches (like, 20g, 5x5x5cm) can survive on their own and possibly develop on into independent instances.

[[Darb ut-Tabānah]]  is in possession of such a instance.
