#Ancients 

Monday, 25. April 2022

11:45

 

None of the ancient people got actually born like that, they all ascended into their powers through arduous roads and many sacrifices.

People who get raised within their small confined exile are just more likely to ascend and are slightly attuned to the twilight looming around all.

Possibly all retired lvl 20 adventurers ascend into their circles.

Gradam Cant is their form of catalysing raw Amarisk into working.

(Lit. Ancient Language)

They have a approx 0.25x scaling on reputation gain.


They're all fed up from groups of selfish, narcissistic travellers who "conquered the world" and now are trying to stop new travellers from getting into their realm by lvl 20.


Forcibly contained by the [[Fountainhead]], as to limit their actions.


| Excellent: |     |
|------------|-----|
| Good:      |     |
| Neutral:   |     |
| Poor:      |     |
| Repelling: |     |