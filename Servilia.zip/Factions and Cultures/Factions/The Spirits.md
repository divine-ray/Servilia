
They reside within, atop and around the [[Floating Islands]].

Affiliating to them will make them aid the Party overall in their journey, by aiding on combat (animating objects to decoy, possessing, manipulating the battlefield) and overall.

Once in a good standing with these, any of them may be summoned using a Polished Silver Mirror.

One of the most primordial manifestations or children of the Twilight.

These are the "foster children" of The Ancients.

Typically invisible aside from their influence on matter (outside of the first Twilight layer) unless [[Birth of Energy|cast]] into a material vessel, who usually is a amalgam of their respective element, crudely held together. 
Some spirits however asked and received a more intricate vessel, such as a mask or engravings on their amalgam, representing some artistic or expressive[^1] features.




[^1]: read: facial, such as eyes, mouth
