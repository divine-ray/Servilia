#Thylyist #Thylyist-Government 

The council of seven individuals governing the City Empire of Thylyist. 
They are seen as ethereal and incorporeal from the population.
Members of the council are very rarely seen in persona and they employ life-extending technology.
Every 16 orbital periods of Heaugi (16op x 64d/op = 1024d) ,they hold a secret vote if one member has become untrustworthy and requires  replacements. 
A replacement is selected from a pool of unknowing citizens.

They always use code names or those that don’t change.

Plottwist: [[Darb ut-Tabānah]], a exilian (he got exiled from the other deities) is now betraying and traitorous towards the other deities and pushes the government to act upon the issue of magic,especially the fountainhead, and ancients.