#Thylyist #Thylyist-Military #Thylyist-Government 
Elite unit of trades- and businessmen, sourced from the [[Labor union of Thylyist]]. 
Under direct rule of Thylyian government and military, and central to Thylyist economy. Well-funded. 
Has been repeatedly tasked to assault [[Frisco]]'s economy, as they're the only notable competitor.