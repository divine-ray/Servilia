#Thylyist #Merchant #Faction 
| Excellent: | Up to 70% Discounts on Merchants, Prototypes and Blueprints |
|------------|-------------------------------------------------------------|
| Good:      | Up to 30% Discounts, Selling Components                     |
| Neutral:   | *Sells regular products at regular price*                   |
| Poor:      | ±30% Increase, grungy Shopkeeps                             |
| Repelling: | Refuse to Trade.                                            |

 

This is the collective Union of salesmen and Workers of Thylyist.
