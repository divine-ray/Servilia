Imperial Currency of the Thylyian, accepted only within Thylyist and associate. 
 

Example References:

 

<table>
<colgroup>
<col style="width: 56%" />
<col style="width: 43%" />
</colgroup>
<thead>
<tr class="header">
<th>1€ Bread IRL:</th>
<th>23 Preni</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><h3 id="peasant-expenses">Peasant Expenses:</h3></td>
<td> </td>
</tr>
<tr class="even">
<td>Food and Provisions:</td>
<td>51 Mang / 4 Renu</td>
</tr>
<tr class="odd">
<td>Rent and Taxes:</td>
<td>63 Mang / 5 Renu</td>
</tr>
<tr class="even">
<td>Misc.:</td>
<td>14 Mang / 1 Renu</td>
</tr>
<tr class="odd">
<td><strong><u>Total:</u></strong></td>
<td><strong><u>157 Mang / 10 Renu</u></strong></td>
</tr>
<tr class="even">
<td><h3 id="income">Income:</h3></td>
<td> </td>
</tr>
<tr class="odd">
<td>Peasant Farmer:</td>
<td>124 Mang / 9 Renu</td>
</tr>
<tr class="even">
<td>Average Citizen:</td>
<td>385 Mang / 28 Renu</td>
</tr>
<tr class="odd">
<td>Solider:</td>
<td>440 Mang / 31 Renu</td>
</tr>
<tr class="even">
<td><h3 id="property">Property:</h3></td>
<td> </td>
</tr>
<tr class="odd">
<td><p>A house,</p>
<p>Cramped but adequate:</p></td>
<td>187 Mang / 13 Renu</td>
</tr>
<tr class="even">
<td><p>A house;</p>
<p>Average for a peasant</p></td>
<td>431 Mang / 30 Renu</td>
</tr>
<tr class="odd">
<td><h3 id="adventuringmisc">Adventuring/Misc</h3>
<blockquote>
<p> </p>
</blockquote></td>
<td> </td>
</tr>
<tr class="even">
<td>Room and meal at a inn:</td>
<td>2 Mang / 426 Preni</td>
</tr>
<tr class="odd">
<td>Basic Horse and Trappings:</td>
<td>13 Mang / 3001 Preni</td>
</tr>
<tr class="even">
<td>Week’s Traveling provisions:</td>
<td>13 Mang / 3001 Preni</td>
</tr>
</tbody>
</table>

4 types of coin: (coin-material)

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 21%" />
<col style="width: 44%" />
<col style="width: 17%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="unit">Unit:</h3></th>
<th><h3 id="material">Material:</h3></th>
<th><h3 id="conversion">Conversion: </h3></th>
<th><h3 id="icons">Icons:</h3></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><h5 id="preni">Preni</h5></td>
<td>Bronze</td>
<td>1 Preni</td>
<td>🥉, BC, B🪙</td>
</tr>
<tr class="even">
<td><h5 id="mang">Mang</h5></td>
<td>Silver</td>
<td>1 Mang = 213 Preni</td>
<td>🥈, SC, S🪙</td>
</tr>
<tr class="odd">
<td><h5 id="renu">Renu</h5></td>
<td>Gold</td>
<td>1 Renu = 14 Mang OR 2.987 Preni</td>
<td>🏅, GC, G🪙</td>
</tr>
<tr class="even">
<td><h5 id="vyahn">Vyahn</h5></td>
<td>Platinum-Gold</td>
<td>1 Vyahn = 5 Renu = 70 Mang = 14.910 Preni</td>
<td>🪩, PC, P🪙</td>
</tr>
</tbody>
</table>

 



 

> Todo, fix the conversion to flat numbers
>
> 1 mang = 1000 preni, 1 renu = 100 mang, 1 Vyahn = 10 mang

 

Pre-ma-re-vy

Premarevy
