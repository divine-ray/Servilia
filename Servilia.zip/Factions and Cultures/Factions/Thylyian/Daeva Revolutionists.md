Daeva Revolutionists

Monday, 25. April 2022

12:34

 

 

The Daeva have made their Advance into this timeline and now aim to overthrow City Empire Thylyist.

They live in the underground and anonymously in the city.

 

A twilight rift probably brought them into our realm.

 

 

 

 

They want Matriarchal rulership and horny

 

They cause a bit of chaos fun time now and then

 

Use plant and biological magics; highly proficient with plant Amarisk

 

They are one path to start [The Word and Thought](onenote:Major%20Quests.one#The%20Word%20and%20Thought&section-id={9CCC79C6-7657-FE46-A4C3-AC2899294882}&page-id={26AFDF30-1835-DB45-8070-17265E8C27B0}&end&base-path=https://nswpad-my.sharepoint.com/personal/felixole_lixenfeld_neue-schule-wolfsburg_de/Documents/DnD%20for%20L’P).
