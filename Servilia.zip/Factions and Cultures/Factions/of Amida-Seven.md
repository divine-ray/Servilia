

| Excellent: |     |
|------------|-----|
| Good:      |     |
| Neutral:   |     |
| Poor:      |     |
| Repelling: |     |

This is the future timeline Thylyist Council, who are fully hollow sock puppets by then.
