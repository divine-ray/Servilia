#Faction   #locations 

An autocratic civilisation of winged, sentient beings, residing in the [[Northern Reaches]] and the [[Crevice Canyons]].

They're extremely agile hunters, and are cultured as such. Due to the nature of their home, they're virtually unable to leave their home due to perfect adaptation to their realm.

Not much is known of these oftentimes violent hunters. Yet, some of the most daring gangs and organisations have praised them for being ideal mercenaries and killing squadrons.

Those few who manage to fight through the deadly conditions of the Northern Reaches oftentimes get adopted into their ranks in a own, special caste.
