# Profile: #Kaa-val 

Loosely organized groups and families with little to no hierachy
These groups tend to be associates such as families, partners and friends
Not a cluster a tribes since groups form and dissolve easily
"Capital City" [[Kaá-Rav]] (moreso a hub of trades, services and housing) located on the [[Left Ribs]]
True neutral in global politics for the most parts outside of self-preservation and security (since they're lacking a central government)
	→Few exceptions in violent chromatic dragons who wage conquest and war for their own good
	These few outliers shape the negative image of all dragonkin, resulting in many "Kill on Sight" orders
	Dragonkin is subjected to genocide attempts by the [[Council of Thylyist]] and it's military.
	But the attackers get horribly defeated 
		But they keep on trying 