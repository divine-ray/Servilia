
 

The Cradle is a decently sized group of scientists from the future timeline of [[Amida]]-7.

They have developed time travel and bring the Party future equip, as they know what must happen to ~~fix a cataclysm~~ manipulate timelines to make their causality exist on.

 

 

> Do they give the engineers of Thylyist blueprints for time machines or do they actually travel to our time themselves?

 

| Excellent: |     |
|------------|-----|
| Good:      |     |
| Neutral:   |     |
| Poor:      |     |
| Repelling: |     |
