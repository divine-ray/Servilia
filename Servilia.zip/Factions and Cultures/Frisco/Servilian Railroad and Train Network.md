#Travel 
The only noteworthy rail network in Servilia, constructed and ran by [[Frisco]]. Mainly steam-driven. 
Most if not all bigger settlements are connected with it, making it the primary means of cargo and passenger transfer throughout the continent. 
[[City of Thylyist]] is not connected due to the ongoing rivalry of Thylyist and Frisco. 
It is built around the Hollow Mountains, avoiding them as Friscan engineers were not aware of [[Dwarves]] that could’ve helped them dig tunnels through the mountains. 

Early attempts at electric trains using overhead conductors are in experimental phases around Frisco. So far, it has not proven profitable and needs refinement. 

Major stations include:
- Frisco
- [[Brisburne]]
- ~~[[Sepulchre]]~~ (Partially, but necessary to balance the load and shorten general travel times.)