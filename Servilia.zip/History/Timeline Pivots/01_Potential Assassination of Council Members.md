Potential Assassination of Council Members

Monday, 25. April 2022

11:41

 

<table>
<colgroup>
<col style="width: 80%" />
<col style="width: 19%" />
</colgroup>
<thead>
<tr class="header">
<th>YES</th>
<th>NO</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>The entire police and military and whatnot will always try to kill THEM</p>
<p>That basically breaks the supply of mechanical components</p>
<p> </p></td>
<td>Nothing, really.</td>
</tr>
</tbody>
</table>

 

 

 

 

Hmm now what if we assassinate Darb ut-Tabānah, once we catch him?
