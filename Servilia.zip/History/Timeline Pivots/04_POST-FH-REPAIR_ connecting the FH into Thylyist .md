POST-FH-REPAIR: connecting the FH into Thylyist

Tuesday, 26. April 2022

13:04

 

This could provide such an energy that they can *skip across timeline branches.*

Instead of solely back in time, so they could manipulate the entire plot and extinction of lavish and ancients!
