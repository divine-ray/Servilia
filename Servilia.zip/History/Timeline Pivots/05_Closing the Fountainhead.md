Closing the Fountainhead

Monday, 25. April 2022

12:42

 

Closing down the Fountain allows the twilight to unfold its natural state again, unharnessed, but possibly more awake than before and thus more conversing

 

Basically this means you make the twilight think freer, like putting down sedation

 

Twilight REP + 75

 

The Council of Thylyist would finally accept that magic is no more of a threat

 

The ancient deities would somehow leave their exile and bring their powers into common life, and local religions and pantheons would flourish.
