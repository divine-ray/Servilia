Repairing the Fountainhead

Monday, 25. April 2022

12:22

 

Doing that would bring back the channeled and ordered form of Twilight **harnessed**

 

The Thylyist Council would actually see that their fear for magic is somewhat unjust

 

The twilight will be so fucking pissed that its getting leeched for (its pov) seemingly nothing

Twilight REP - 75
