Open Affiliation to the Arcane

Monday, 25. April 2022

11:42

 

If THEY open up that THEY are skilled in weaving Amarisk, Thylyist is going to look at them very closely and hold that at stake for any (assumed) misbehaviour

\>\_ highly increased "watch level"
