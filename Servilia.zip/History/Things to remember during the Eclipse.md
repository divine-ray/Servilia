 THINGS TO REMEMBER DURING THE ECLIPSE 
 1. Hopkinsville may have the best viewing, but they will also be the first to be sacrificed.
 2. Animals may behave strangely, If your dog speaks like a man, heed it's dire warnings.
 3. Don\'t trust the squirrel with a child\'s face. It speaks only lies. 
 4. When your double arrives, resist the inclination to fight it. It may be stronger than you. Chances are, it will disappear after the eclipse. 
 5. If you stare into the void and it blinks first, it wins. The prize is insanity.
 6. Werewolves are not only impossible to kill during an eclipse, they become SUPER werewolves.
 7. Whatever you do DON\'T buy any weird plants, we don\'t want a repeat of last time.
 8. if once upon a time you were falling in love, but now you\'re only falling apart, there is nothing you can do. That\'s a different kind of eclipse.
