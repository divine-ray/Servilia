
The ancient deities figured out that death itself is not beatable or can be exploited, so they reached further and killed or lethally injured their father.

This caused death itself to become depressive and unable to perform their job as universal terminator, rendering all people afflicted with the curse of the undead.

Death itself is a fragment of [[Beings/Beyond/Schi ut-Pula|Schi ut-Pula]] as it is central to any and all happenings on Schi.
