come, little one. let us observe.  watch over these others. they shall learn to fly. its sad seeing them, limp and glum, on the floor.
we shall teach them flight. allow them to ascend and conquer the air, follow our lead. you have to tell them: spread your wings, breathe, flap, repeat. flight is important. we need the air. 
see, big one. you shall fend off our islands. there are others who want to take our small refuge. we cannot allow them. our islands are home to us and the elders. 
you are gifted with flight. but you are also anchored, see, this is your core. do not let them near it. you wield big powers, but you can handle that. 
but fear not, you are not alone. other ones are around to support you, and you support them. unity is strength. without unity, we fall.

these islands are important, you must know. our service keeps them afloat and healthy. the elders cherish our work, our floating islands. they are very important. but don’t forget, we share these islands with the elders. while they more like the ground, the lizards enjoy our islands. their gratitude is our joy and will to keep on going.
gather round, little ones, cherish the shrine to the lizards, over at their side of the ribs. you here, tend to the plants afloat and aired on the islands. plants are good for the air, you must know. remember, we need the air. someone, prepare, and look on the digging ones. we cannot risk having them eat our islands and mountains. a big one shall accompany you. 

*** 

bone, to carve a shape.
golden plating, for conductivity. 
feathers, for flight. 
claws, for defense. 
a whiff of powder, for energy. 

