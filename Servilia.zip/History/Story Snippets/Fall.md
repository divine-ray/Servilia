Sirens howling 
as the large things draw cross the sky and keep dropping their 
unknwon gifts which a
which kill what have we done wrong to draw the anger of these beings
who are clearly superior to us 
what did we do wrong 
someone help 
it's all on fire 
screams  terror   panic    the stench of dust from buildings collapsing 
someone 
help 
we did nothing wrong 
surely our govt will protect u
the govt will help us
smite those creatures away
noone shall harm us again
let us rise, brothers, sisters and fellow siblings
let us reclaim and fight back
we shall not be suppressed by anyone
we are    
	above all 
	we are ruling
i utter these words as a gunshot rings in my ear
	and a shrapnel tears through my body,
	not caring of me 
	it obeys physics
. . .

. . . 

hours later
the creatures have stopped giving their gifts
our city lies in ruins 
i cannot find anyone i know
everyone just on the floor
dead or alive, a difference 
	so small i cannot tell
where is 
	my family
	my friend
	my pet
	my mind
	me
help

. . .

another time 
more sirens
more death and devastation
for no purpose


i am sorry this is always this is always how this goes
the wind blows loudest when you got your eyes closed
but i never changed a single colour that i breathe
we are tired of letting it all in
we are tired of punching in the wind
so i take off my face
i do not want to be recognised
i want to loose myself
without loosing my life
	thats a lie
and i tear at my lungs
they remind me how it all went 
	wrong

so i cower
in the corner of what used to be a 
	my
house.. 
i cannot breathe
my lungs are torn 
my throat is choked
choked by the rubble i ate
to satisfy a false hunger

someone has 
seen me
i wimper in fear
is it one of the gift givers 
no
they walk
i cry
they come nearer
they speak 
	a language unknown
i answer
but they only hear screams
i scream 
in fear
a metal shimmer
i weep in fear
they
stop 
stop moving
dropped to their knees,
	scratching open their face
	and they take 
	off their face
	because it reminds me how it all
		went wrong
	and they pull 
	out their lung
		because it reminds me how it all
			went wrong
they 
died
curled in anguish i weep 
to commemorate this tragic individual 


