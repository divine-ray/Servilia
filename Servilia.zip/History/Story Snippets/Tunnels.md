There’s a hatch in my basement. 
I have no idea how it came to be, but i know that I cannot lock it. 
My family always forbid me to move the old and unused metal oven that stood in front of it.
Now that they are dead…
I moved it anyway. Now i know. 
*** 
Dear god.
I never thought that i had access to a personal railway line… 
Behind the hatch is a tunnel. Many tunnels. Full of rails, but rusted and forgotten. 
The stench… Who knows how many hundreds if not thousands of vermin have birthed, lived and died here… Gross. 
