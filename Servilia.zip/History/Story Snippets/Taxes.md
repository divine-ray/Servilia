A betrayal. A backstab. A reunion.

Panic amongst them, for the consensus is due.
The tally for silver and gold.
The collectors chase them, as they're unwilling to yield. The collectors are everywhere. They are inevitable. 
Flight is ineffective. They face the anguish and dread, just to cower away. The collectors fulfil their task and execute them, for they are unable to provide the tribute. A clean shot, a smooth movement of the blade. 
This is set in stone; it repeats itself forever.
Another remark on a paper that'll be soon catching dust: "Unable to yield, executed." No-one will ever read this. No-one will spend a second thought on these lives lost. The one who wrote this note knows, and is blissfully aware yet ignorant about this. 
"Who cares, either way?"
Engineered and optimised to perfection. Designed to consume and subsume.
The bureaucracy, given firearms and blades. 
Pen and paper is for the weak.
We take. 
**And give.**


These are the [[Dogs of War]].
