
(As of 6/5/22)
(for the playing party)
[[Darb ut-Tabānah]] has recently been seen travelling the realm (despite being claimed dead), heading towards Thylyist.

~~He aims towards the Thylyian Government to exploit their fear towards the arcane and use it to finally deal with the fountainhead~~.

The Party could set on that rumour and try to catch the proclaimed-dead Ancient and to interrogate them.

~~If that doesn't happen,Darb ut-Tabānah will sneak into the Thylyian government and do things to get them towards the Fountainhead~~.

> In case the above takes place, he'll publish materials to guide adventurers and such towards the Fountainhead, massively destabilising the Thylyian society because "ooo magic spooky"


 

**Who?** Darb ut-Tabānah.

**Why?** He has become a widergänger and is aiming to throw revenge at the void for storming Londo.

**What?** He makes his way into the Thylyian Government and exploits their fear for magic to achieve his goal of **Deal with The Fountainhead.**

**Where?** The Council of Thylyist.

**When?** "modern" era, present. 
