#QUEST #Undead 
>**OBJECTIVE:** Protect [[Sepulchre]] from [[Chézke-an]], who plots to harvest and enslave all citizens for its foul purposes. 
