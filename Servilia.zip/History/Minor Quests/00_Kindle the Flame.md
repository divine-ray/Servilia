Kindle the Flame

Monday, 25. April 2022

12:24

 

**Main objective: Supply The Flame with suitable Sacrifices.**

 

[Detailed Description:]{.underline}

*If-condition:*

-   Must know the CoTF.

 

-   Retrieve blazing Items from the Realm.

    -   Embers, Smoulders, Firekeepers (sacrifice), solid Amarisk.

        -   Offer them to the Brightest Flare.

        -   They'll offer them to The Flame and do stuff.

 

[Conclusion]{.underline}:

Reputation increases within the CoTF.

Repeating this quest may turn the delivering character Ashen.

 
