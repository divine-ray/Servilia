Tides of Avon

Friday, 29. April 2022

10:38

 

**Main objective: Investigate the abnormally extreme tides of Avon.**

 

[Detailed Description:]{.underline}

The citizens, especially maritime folk, have reported extreme tides (flooding and ebb), and they reached out to the newfound adventurer party.

-   Research about similar occurrences.

-   Localise the phenomenon.

    -   The source is supposedly a big ass sea serpent which makes vortexes.

    -   Either:

        -   Negotiate with it by offering food regularly (try to not get eaten)

        -   Slay it.

 

[Conclusion:]{.underline} Reputation increase, 🪙 reward, sea serpent scales + bones (crafting/magic component).

 

*Optional:*

-   Task

[Alternative Conclusion:]{.underline} Lorem Ipsum Dolor Sit Amed

 

Unlocks when everyone is level 5

 

Intro quest by the way

 
