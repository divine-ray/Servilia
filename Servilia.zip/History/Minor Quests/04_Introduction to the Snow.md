Introduction to the Snow

Friday, 29. April 2022

09:18

 

**Main objective: Discover the Cold.**

 

[Detailed Description:]{.underline}

-   Travel to the coldest area of the Realm.

    -   Locate the Heart of Cold.

-   Collect information on the Cold (telepathy, scouting, research).

    -   Note these down.

 

> *SWITCH:*

-   Publish them to the Academics of Thylyist.

 

> *OR:*

-   Keep the notes together.

 

*If 'publishing' the notes to the Academics of Thylyist:*

[Conclusion:]{.underline} The Realm is now aware of the Cold. Military movements is likely to follow.

 

*If keeping the notes to themselves:*

[Alternative Conclusion:]{.underline} The Party bears the weight of knowledge, and must properly handle the Cold until further notice.

 
