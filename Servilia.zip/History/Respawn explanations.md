

-   Curse of the Undead (Default)
	%%Curse of the undead caused by corruption and Between Twilight upon humans%%

-   Vessel 
	%%Hollow knight vessel, aka void container%%

-   Ashen 
	%%Incineration/Cremation caused by the Blazing from Children of The Flame%%

-   Neophage
	%%Neophage is an amorphous artificial organism, a core capable of burying into bodies and controlling them.%%

-   Spirit-induced Animation
	%%Closely related to a golem, these beings consist of anorganic, motive and cognizant mass, coordinated by possessing spirits.%%

- Frozen/Cold Husk
	%%Frozen/Cold Husk as a entity that has obtainend some degree of autonomy from The Heart. %%
***


