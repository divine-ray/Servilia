#Thylyist 

 

The pre-pre-predecessors of their culture and technology were actually weaving magic into their mechanisms and such, and after The Ancient Happening (TAH😛) the then-council banished and stigmatised any arcane doing, but the usage of beryllium bronze as main alloy remained.

⬆️This makes all machinery react really interesting with magic

Oi, what if the beryllium bronze attracts spirits and they try to ward them off?

 

The Ancient Happening occurred in around 1950-1970's of their time

 

Brotherhood Backstab is the entry into the Deep Archives of their doing of nuking the Lavish (Dated 1971)

 

The Thylyian council has fallen unknowing of their doings in the past, and thus forgot about the Fountainhead.
