TL;DR Plot

Tuesday, 26. April 2022

08:15

 

Three major factions; the Ancient Deities, the Thylyist Federation, and the Empire of the Lavish.

 

The Thylyist are extremely afraid of magic and the deities, and decided to use the lavish to banish the deities, then nuke the lavish.

 

The starting scene is "ohshit the gods are about to screw us over, get the elite gang and banish these fucks again"

 

> **Story like it's the main motivator to deal with the fountainhead and the deities**
>
>  

 

Yo if they goin to actually violently destroy the fountainhead it'll rip spacetime and a-7 will leak into our timeline

 
