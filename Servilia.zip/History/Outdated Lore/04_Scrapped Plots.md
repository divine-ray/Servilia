
The party starts out with the thylyian doctrine "magic = bad."

 

 

**Who** (Actually is their secret founder, and who are themselves)**?** They've been put together as "mobile task force" by (to them) secret group, with the task to travel to The Wastes (they also don't know that its dangerous af).

 

**What** (assembled this group)**?** The thylyian council in a covert mission to eradicate the Fountainhead. (The party just knows "go to there and break it").

 

**When** (is the entire setting)**?** Jelune, the 1st Durthrou, 1013.

 

**Where**? Within the entire Realm (name pending).

Why (have they been tasked with this)? The thylyian council is using them as MTF to kill the lavish remains, to clear off the records of the actual world. No one's been good enough for The Wastes yet.

 

 

 

 

 

 

 

 
