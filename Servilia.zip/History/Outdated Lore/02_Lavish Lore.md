Lavish Lore

Monday, 25. April 2022

12:57

 

The lavish somewhen discovered the twilight and (skip) opened a physical way to the Twilight by piercing the fabric of reality

 

That required the most powerful Catalyst ever seen

> Do lore for Catalyst
>
> (Soul of a Ancient Deity?)

Through The Pierce, the Lavish ascended to a power level that threatened the Ancient Deities, who are big fans of harmony and they massively hated the Lavish for harming their (sentient, after all) power source

And somewhere in the cataclysm that's euphemised as "Brotherhood Backstab" the Catalyst got lost and the Fountainhead lost its harnessing power, creating a source of Chaos and Twilight's Wrath at the center of the Lavish

 

This might be some of the Chtulu fuckers, "Gedankenschinder"

TL;DR the lavish were aquatic beings, residing in a massive lake/semi ocean

 

Also the lavish were so keen to merge magic and technology into feats which now are high traded artefacts and powerful gear
