#Ancients 
 

Actually the ancients were quite friendly since they wanted to bring the gift of Twilight, Amarisk and Arcane to all Humanoids.

 

This is less of a species but more of a category for beings that are so proficient with magic, arts or technology that they have been seen as gods by common folk.

-   Ascended Level 20 Characters

 

These are like the "big friendly giant"-sorta individuals since they realised that war or disinhibited aggression is not thriving, only degenerating

Somewhen New Londo got overrun by loose and broken vessels, which caused a generational trauma there

This led to the Ancients to collect all Masks and Mask Shards they could find and pile them up in the Limbo Boneyard.
