

People did decide against electricity and semiconductors as technology and got into steam and biotechnology.

 

When the 19th century wound down they discovered the potential of magic and attracted the Ancients

And they were suddenly aware of magic powers and the destructive potential.

So the last thing they did with magic was to condense a fuckton of Chaos into a nuclear warhead and to yeet that at The Fountainhead of Lavish

The lavish people were actually just finished with their part of The Ancient Happening and they get fucking magic-nuked by their "allies"

-\> Brotherhood Backstab (1971)

 

And yea the ancient deities are on the rise again because the fountainhead is broken, which usually held them in containment

It's broken but its now on the brink of collapse and all fucky things come over through it

The current scene is "ohshit the gods are about to screw us over, get the elite gang and banish these fucks again"

 

The date of THEM (our gang) is somewhere in 2030's
