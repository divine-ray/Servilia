#QUEST 
 

### **Main objective: Meet these whom bear the Curse of the Undead and get in touch.**
#### Learn about Sepulchre and it's residents.

 

[Detailed Description:]{.underline}

 

 

[Conclusion:]{.underline} Unlocks story options towards the Undead and lore about the CotU.

 

*Optional:*

-   Task

[Alternative Conclusion:]{.underline} Lorem Ipsum Dolor Sit Amed

 
