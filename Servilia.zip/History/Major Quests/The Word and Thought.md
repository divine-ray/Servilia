 #QUEST #Story

**Main objective: Retrieve (and optionally use) the Seed of Thought.**

 

### Detailed Description:

*Only if details are enquired:*

-   Listen to the Daeva Revolution leader.

    -   They'll tell The Party about a rumour of this mystical Item.
-   Listen to the story of the Two hangmen.
    -   They mention the existence of "the seed of thought, who must not spread"
    -   Obtain their Faulty Rope (quest item).
-   Travel to the ancient Exile.
-   Retell their story to one of the nature-affine deities.
    -   Present the Faulty Rope.
-   Get the Seed of Thought.
-   Present the Seed to the Two Hangmen.
##### *Optional:*

-   Plant the seed in a central area of Thylyist, causing the Daeva Revolution to take place.

-   (Congrats, thylyist military hates the party now)

>  
