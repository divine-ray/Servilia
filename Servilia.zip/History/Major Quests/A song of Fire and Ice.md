#QUEST 
 

**Main objective: OBJECTIVE.**

 

[Detailed Description:]{.underline} Play off [[Children of The Flame]] against the [[The Cold]], and cause the downfall of both parties.

 

*If-condition:*

-   Knowledge of CoTF && Heart of Cold aquired?

    -    

 

-   Task.

    -   Detail 1

        -   Sub task.

 

[Conclusion:]{.underline} Text

 

*Optional:*

-   Task

[Alternative Conclusion:]{.underline} Lorem Ipsum Dolor Sit Amed
