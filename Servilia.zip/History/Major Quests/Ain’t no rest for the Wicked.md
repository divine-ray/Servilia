#QUEST #Undead 

**Main objective: Discover the [[Sepulchre|Necropolis]].**
>Discover the [[Two Hangmen]] hanged by a tree on top of a hill close-by to [[Lost City of the Ninth Forest|a devastated city]].

They will tell their tale[^1], and offer instructions towards entering [[Sepulchre]].

Follow-up: [[It’s a dead Man’s Party]]


[^1]: