

Idea: some Scientists (known as [[The Cradle]]) from [[Amida]] travel back in time and bring THEM the capability to travel time or switch timelines

 

Gotta balance this shit lmao
