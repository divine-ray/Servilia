Them. The eleven figures, all seen across space and time. 

Apartment 402 calls them their home.

There's a crack in every wall. 

A glass front, facing ethereal stretches of mountains covered in forest.

A glass roof, giving light to unseen constellations. Then, it is milky and blurs any clear observation.

Walls of green, breathing the air. This, for cleaning. The bird likes the greenery. 

A jukebox. Constantly playing a ever changing tune.

To the right, a doorway, embedded in the green. Gates, enough to fit a winged lizard. 

A platform, its edge unprotected. Its walls fading into nothing. The three lizards fly from here.

Couches, to sit and lay down on. 

A floor, made from stone. It is warm and comforting. The lights often lay on this floor. 
The white spends its time on this floor. 

A staircase, leading down. Down are the rooms. 

When the sunlight hits the dust
When I loose my grip and fall 
will I die?

A hall, resembling a museum.
Many exhibits. Showcases, paintings, hollow glass cubes. Most peculiar objects. 
Lights, don't you see? These are our substance. We rely on them. They are memory. We cannot afford loosing them. 
See, this mask. It is fractured, damaged. Surely, this did not happen peacefully. It is hurt, requiring time and care.


The machine. It needs a new vessel. It shall inhabit the future's organism.

The star. It is severed from it's origin. For it is a Pula, It is unknown. 

The golden. The home has served its purpose. It seeks a new purpose.

The black. Loss of orientation.