Generation and tools

Thursday, 28. April 2022

08:53

 

<https://donjon.bin.sh/fantasy/dungeon/>

<https://donjon.bin.sh/fantasy/treasure_map/>

 

 

 

<https://donjon.bin.sh/fantasy/town/>

 

<https://www.rangen.co.uk/world/solargen.php>

 

`{"year_len":246,"events":1,"n_months":9,"months":["Durthrou","Navarn","Bakk","Nika","Banara","Stvlisa","Apsni","Zari","Listija"],"month_len":{"Durthrou":27,"Navarn":27,"Bakk":27,"Nika":27,"Banara":27,"Stvlisa":27,"Apsni":28,"Zari":28,"Listija":28},"week_len":9,"weekdays":["Jelune","Disul","Sadorn","Lundia","Erdai","Jovdai","Brespod","Duaro","Senin"],"n_moons":3,"moons":["Opar","Scheties ","Heaugi"],"lunar_cyc":{"Opar":11,"Scheties ":27,"Heaugi":64},"lunar_shf":{"Opar":1,"Scheties ":0,"Heaugi":0},"year":1020,"first_day":6,"notes":{"1018-2-12":"Triple Fullmoon","1018-5-25":"Comet appears, Triple Newmoon"}}`
 

<https://donjon.bin.sh/fantasy/calendar/>
