Politics and Negotiation

Monday, 25. April 2022

11:20

FACTIONS

 

Yes, They are capable of negotiation with all factions and can possibly Turin them peaceful
