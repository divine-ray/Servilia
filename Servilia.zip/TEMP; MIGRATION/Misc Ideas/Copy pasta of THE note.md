# DO NOT DELETE

 

**Gay DnD**

 

Areas:

\- arcane-like Steampunk city

\- cyberpunk 2077 night city

\- dream realm

\- hallownest

\- Hollow mountains (dragon roost and underworld like)

\- The wastes (salt flats, creepy, nuclear ruins)

Enemies in areas:

\- Steampunk:

\- - \[B\] Clockwork dragon, Rastaban

\- - Brass Sentinel

\- - \[B\] Zeppelin Warship

\- - citizen

\- - Elite Guard

\- - Sentinels (basically police)

\- - Armed Automaton

\- Cyberpunk

\- -

Merchants in Areas:

Steampunk:

\- Tinkerer (big, chonky guy with dangly gear who works on whatever, story related)

\- Retired Sentinel (provides outdated Intel on the sentinels, and mimicking equipment)

\-

Merchants in general:

Items in areas:

Items in general:

Vehicles and transport:

Artifacts:

Storyline:

 

Politics and negotiation is possible with the \"bad guys\" -\> pacifist run

 

Kills on factions cause reputation to drop

\- possibility to make allies with factions, up until they represent the player group

\- or become peaceful

 

Quests for assassinations ?

 

Souls like enemy scaling

 

Oh fcuk dialogue Interactions for flirting?? no hrony

 

Time traveling mechanics, in a simplified and costly fashion
