Depressive celestial

Tuesday, 3. May 2022

11:42

 

What if some elder god or creator being (cough, me) had/has a severe depression which spread the curse of the undead across the Realm?

Because the CotU is a metaphor for depression, becoming hollow and all nasty when you don't have a drive or motivation
