SCP presence

Monday, 25. April 2022

12:35

 

Ill argue with myself if I should include SCP references

 

 

 

But having the Daeva as oppressed faction and revolutionists in the Era of Thylyist would be ducking cool

They're the full opposite of the council and I might nudge THEM into aiding them to overthrow Thylyist Council

 
