Questions!

Thursday, 5. May 2022

10:20

 

Zumindest die meisten D&D-Kampagnen erfordern die fol-

genden Elemente:

Eine Ursprungsebene für Unholde

Eine Ursprungsebene für celestische Wesen

Eine Ursprungsebene für Elementare

Einen Ort für Gottheiten, der zugleich auch eine (oder meh-

rere) der vorgenannten Ursprungsebenen sein kann

Den Ort, an den sterbliche Geister nach dem Tode ziehen

und der zugleich auch eine (oder mehrere) der vorgenannten

Ursprungsebenen sein kann

Einen Weg, um von einer Ebene zu einer anderen

zu gelangen

Eine Möglichkeit, mit der Zauber und Monster funktionie-

ren, die die Astralebene und die Ätherebene benutzen

 
