
	I can almost hear the hounds
	What kind of man built a machine, to kill a girl,
	He must not have used his hand, but a tool

Elite hit squad in the [[Central Thylyist Armoury|Thylyian Military]], solely consisting from captured [[Pseudoneo]] quadrupeds from past the Betrayal. 
Their handlers are under direct control and obey to the [[Dogs of War]]. 
They are *extremely* violent, or rather, have been misused and repurposed to be so, and are stored within a own high-security sector in the Armory. 
Likely the second-highest secret of the Thylyian Military, if not **the** highest. 