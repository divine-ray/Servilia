Assemble the World

Thursday, 28. April 2022

12:15

 

 

Short conclusion of map and areas:

 

-   city empire of thylyist, laid In a moderately hilly place which transitions to a massive cliff falloff

-   Hollow mountains encircling the Floating Islands, in close proximity to

-   The Waste Flats, big outstretched salt flats in proximity to a desert, dead rivers

-   Arctic tundra

    -   And glacial / polar ice plains, home to the Heart Of Cold

-   Volcanic and desert-y hot lands, home to the CotF (they still live underground)

    -   The hot hot grass fields; slightly charred at their area

    -   Steam gardens

> <https://azgaar.github.io/Fantasy-Map-Generator/>
