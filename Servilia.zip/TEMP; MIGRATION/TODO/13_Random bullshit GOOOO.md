Random bullshit GOOOO

Donnerstag, 12. Mai 2022

21:15

 

so a umbrella that when opened up it forms a portal that leads to a part of space basically

 

Butterfly knife but it is sentient and neutral evil, constantly tries to stab the user?

 

i was thinking of an acutal wand that works like a flip knife but that works
