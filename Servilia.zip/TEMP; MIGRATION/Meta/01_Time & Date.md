Time & Date

Thursday, 28. April 2022

09:45

 

{\"year_len\":246,\"events\":1,\"n_months\":9,\"months\":\[\"Durthrou\",\"Navarn\",\"Bakk\",\"Nika\",\"Banara\",\"Stvlisa\",\"Apsni\",\"Zari\",\"Listija\"\],\"month_len\":{\"Durthrou\":27,\"Navarn\":27,\"Bakk\":27,\"Nika\":27,\"Banara\":27,\"Stvlisa\":27,\"Apsni\":28,\"Zari\":28,\"Listija\":28},\"week_len\":9,\"weekdays\":\[\"Jelune\",\"Disul\",\"Sadorn\",\"Lundia\",\"Erdai \",\"Jovdai\",\"Brespod\",\"Duaro\",\"Senin\"\],\"n_moons\":3,\"moons\":\[\"Opar\",\"Scheties \",\"Heaugi\"\],\"lunar_cyc\":{\"Opar\":11,\"Scheties \":29,\"Heaugi\":64},\"lunar_shf\":{\"Opar\":0,\"Scheties \":0,\"Heaugi\":0},\"year\":1018,\"first_day\":8,\"notes\":{}}
