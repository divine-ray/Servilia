Irr-ational explanations (Q&A)

Friday, 29. April 2022

10:28

 

**Q:** Why is it easier to use flying airships than to traverse the ground?

**A**: The technology is long-established and cheap, and relatively safe. Burglary or raids are only possible while loading/unloading, and ground-to-air assaults are too much of a attention-grabber.

 

**Q:**

 

**A:**
