Ash:

Sunday, 29. May 2022

16:37

 

<https://www.dndbeyond.com/characters/74765860/gYDFnv>

 

 

Lifestyle: comfortable

Faith: slay that dragon

 

 

Neutral good

 

 

Grown up in a forest

224 y o

Wants to revenge master who died on the 100th birthday

Slain by dragon

 
