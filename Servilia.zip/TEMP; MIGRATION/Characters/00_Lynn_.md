Lynn:

Monday, 25. April 2022

12:27

 

<https://www.dndbeyond.com/characters/72779987>

 

They witnessed the raid of New Londo from Loose Vessels, and vaguely know Darb ut-Tabānah.
