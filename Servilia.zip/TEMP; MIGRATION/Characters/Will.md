

<https://www.dndbeyond.com/characters/62385830/Ze9y6J>
