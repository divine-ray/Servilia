Status Effects

Tuesday, 26. April 2022

11:40

 

| ~~Stunned~~       |     |
|-------------------|-----|
| ~~Restrained~~    |     |
| Prone             |     |
| *Poisoned*        |     |
| ~~Petrified~~     |     |
| Paralysed         |     |
| Burning           |     |
| Hunter's Mark     |     |
| Mage Armour       |     |
| Invisible         |     |
| ~~Incapacitated~~ |     |
| Grappled          |     |
| Flying            |     |
| Exhausted         |     |
| Divine Favor      |     |
| Concentration     |     |
| Deafened          |     |
| Blinded           |     |
| Bleeding          |     |
|                   |     |

Movement-related Effects

 

| Stunned       |     |
|---------------|-----|
| Restrained    |     |
| Petrified     |     |
| Paralysed     |     |
| Incapacitated |     |
| Exhausted     |     |
|               |     |

Oil

 

 

Health-affecting Statuses

| Regeneration |     |
|--------------|-----|
| Poisoned     |     |
| Irradiated   |     |
|              |     |

Sensory-Affecting Effects

 

| Blinded       |     |
|---------------|-----|
| Deafened      |     |
| Concentration |     |
|               |     |
