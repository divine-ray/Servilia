Values, variables, all that

Monday, 25. April 2022

11:44

 

## Reputation: 

Indicator for Standing to a Faction

<table>
<colgroup>
<col style="width: 30%" />
<col style="width: 69%" />
</colgroup>
<thead>
<tr class="header">
<th>-100 to -65</th>
<th><p>The Faction hates you</p>
<p>and is massively pissed</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>-65 to -30</td>
<td><p>The Faction dislikes you</p>
<p>And may deny services</p></td>
</tr>
<tr class="even">
<td>-30 to +30</td>
<td><em>Neutral range.</em></td>
</tr>
<tr class="odd">
<td>+30 to +65</td>
<td><p>The faction likes you</p>
<p>And may offer additional services</p>
<p> </p></td>
</tr>
<tr class="even">
<td>+65 to +100</td>
<td><p>The faction really likes you</p>
<p>and is going to give you benefits</p></td>
</tr>
</tbody>
</table>

Ranges from -100 to 100

 

 

## Watch Level:

The rating how cautious a Faction handles THEM

 

## Hollowing:

How much one's soul and body has been crunched by chaos

And undead
