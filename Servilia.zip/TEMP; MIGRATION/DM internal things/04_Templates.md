Templates

Friday, 29. April 2022

11:03

 

**Main objective: OBJECTIVE.**

 

[Detailed Description:]{.underline}

*If-condition:*

-   If-operator,

    -   Task

 

-   Task.

    -   Detail 1

        -   Sub task.

 

[Conclusion:]{.underline} Text

 

*Optional:*

-   Task

[Alternative Conclusion:]{.underline} Lorem Ipsum Dolor Sit Amed

Conflicts:

 

**Start, Scale, Stakes, Settle**

 

**Location:**

 

**Dangerousness:**

(**C**reatures-Traps-**E**nvironment)

 

**Possible Loot:**

(**E**quipment-**V**aluables-**C**urrency)

 

**Who?**

**Why?**

**What?**

**Where?**

**When?**

-   Why are all these conflicts happening to my players, and what strings link them all together?

-   How does this all come to a conclusion?

-   Based on the plot so far, would these decisions make sense?

-   Does my new content make sense when compared to the first few events that started this whole thing?

**Example Organisation:**

*Description; structure; members; noteworthy history*

 

> ***Motto:***
>
> ***Creed:***
>
>  
>
> ***Goals:***
>
>  
>
> ***Typical Tasks:***
>
>  

| Item Size:   | XS/S/M/L/XL/G/C |
|--------------|-----------------|
| Item Weight: | VL/L/M/H/VH/M   |
| Value:       | C🪙,S🪙,G🪙,P🪙 |

 

What purpose has the settlement?

How big is it? Who lives there?

How does it look, how does it smell and sound?

How does it defend itself?

Is the settlement part of s bigger compound or state?

Where do people find wares and services which they need?

Which temples and organisations are important?

Which fantastic or supernatural Elements make it different to a common settlement?

Why should the party worry about the fate of this town?
