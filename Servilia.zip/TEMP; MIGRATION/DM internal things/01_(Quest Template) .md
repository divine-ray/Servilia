(Quest Template)

Friday, 29. April 2022

08:42

 

**Main objective: OBJECTIVE.**

 

[Detailed Description:]{.underline}

*If-condition:*

-   If-operator,

    -   Task

 

-   Task.

    -   Detail 1

        -   Sub task.

 

[Conclusion:]{.underline} Text

 

*Optional:*

-   Task

[Alternative Conclusion:]{.underline} Lorem Ipsum Dolor Sit Amed

 
