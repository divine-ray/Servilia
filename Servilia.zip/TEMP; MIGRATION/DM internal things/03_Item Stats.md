Item Stats

Thursday, 28. April 2022

13:08

 

| Item Size:   | XS/S/M/L/XL/G/C |
|--------------|-----------------|
| Item Weight: | VL/L/M/H/VH/M   |
| Value:       | C🪙,S🪙,G🪙,P🪙 |

Very small, small, medium, large, very large, gargantuan, colossal

Very light, light, medium, heavy, very heavy, massive

Copper Coin, Silver Coin, Platinum Coin
