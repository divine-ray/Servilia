Colossal black monoliths, reaching into the sky. Dark, yet brightly lit in neon colours, bringing down a foul copy of Utuw's light upon the eye. 
The regular placement of these pillars is broken up by their awful asymmetry and tumorous growths of railings, catwalks and other indiscernible objects. 
Below, a gaping abyss, half-lit by artificial lighting, extending downwards, breaking any perception of depth. 
Above, a sickly grey cover of clouds, pierced by the monoliths. 

You are lost. 
Everywhere you look are these monoliths. 
Where is the ground?
