

Sold by the [[milkman]], high grade milk

Can be used for alchemy

Good healing item

 
