
A searing hot splinter, seemingly struck off from a large red gem.

There is a smaller coating of ash baked onto it.

Despite being extremely hot, you can hold it like any other item.
