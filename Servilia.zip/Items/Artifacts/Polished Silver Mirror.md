
*Starting item for those with a familiar.*

A fancily polished silver mirror.

The grip is plentifully engraved with Runes.

*If capable of reading Ancient:* "Spirit, Travel, Journey, Me \| I, possess, power"


##### To summon the attuned familiar spirit

######  *chant, calling the spirit by name:*

> Hearken to these words
>
> Hear my cry
>
> I call to you spirit from the other side
>
> I wish to speak to you here
>
> Come to me
>
> Come to this mirror
>
> I call you now, (spirits name)!

 
In case of a starting item: they are soul bound, and cannot be dropped nor sold.


| Item Size:   | Small           |
|--------------|-----------------|
| Item Weight: | Very light, 1kg |
| Value:       | 4 Mang / 0      |