#Item 
The massive construct inserted into The [[Fountainhead]], required for sustained operation.

Consists of many exotic materials and is highly fragile, care is advised.

 

It looks like a long cylinder, two to three men high and inscribed with arcane runes.

*Magical Attunenent: Perceiving this object of immense power makes your powers squirm with fear.*

 

 

*A strange smell and whizz is in the air...* (ozone creation from the highly potent technomagy)

 

Weight: MASSIVE

Size: Huge

Value: Can't be traded
