Eldritch Brand

Tuesday, 3. May 2022

11:08

 

**Wondrous Item**

**Origin:** *Great Old One.* This item was created by an eldritch abomination from the cosmos or ocean depths, or a cultist or warlock of such a being. Its appearance incorporates eyes, tentacles, mouths, and beaks, some of which might move on their own or whisper horrible gibbering sounds. Whatever its powers, they are great and terrible. Anyone using this item risks losing their mind, and few are brave or foolish enough to do so.

**Major Property:** *Stealth.* This item is made for stealth or disguise. It might mask its user\'s appearance, prevent them from making noise, or turn them invisible.

**Minor Property:** *Indestructible.* This item is immune to all damage except one specific type, or it can only be destroyed through special means.

**Special Property:** *Key.* This item is the key to a lock or portal sealed with powerful magic.

 

This should be the key to the Limbo Boneyard.

When carrying, the image of the Great Old One will engrave itself into the user, giving +2 fixed insanity after 1 week in game.

This mental branding is building a immunity (50%) to future insanity.

To Access the Void, the Eldritch Brand is required.

Will be consumed by unsealing the Void, after passing though the entire Twilight.
