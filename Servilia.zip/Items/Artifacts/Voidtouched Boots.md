#Item #items
These Boots have been crafted by the [[Ancients]]  in attempts to stride upon [[The Void]].
They appear as shimmering blackleather boots that has been blackened at some parts. The sole seems to be a unidentified durable rubber or similar flexible material. The cap of each boot is reinforced with a rounded metal cap, although it's not clear if this is steel or something else.
They seem very rugged yet durable. 

Although the wearer may die, the Void will always retch them out.

Major property: **Shifting** 
These boots allow the wearer to partially transcend above realms to stride in the void. 
Additionally, these boots will mould and shape themselves to fit upon the wearer.
 

*Effect: whilst wearing, any individual not aligned with the Void may "safely" trespass it.*
(They're still exposed to the void and it's corrupting influence.)

Weight: light

Size: Small

Value: 5000 platinum coins
