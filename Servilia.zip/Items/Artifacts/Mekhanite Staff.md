#Item #Weapon #Mekhanites #Religion 
**Staff**

**Origin:** *Mekhanite.* This item was created by devoted followers of Mekhane, the Broken God consisting of mechanisms and gearwork. It was created by the Thylyian Department of Construction. It is forged from beryllium bronze and steel, and it incorporates gears and other mechanical parts. Its powers are extremely predictable and reliable (often not requiring a roll for abilities that normally do), and might relate to constructs or creating order.

**Major Property:** *Construction.* This staff greatly enhances one's ability to create mechanisms and constructs by acting as universal tool and energy source. Someone who wields this staff is directly recognised as authorised person by complex automata that accept orders. It is highly sought after by the [[Citadel of the Gear]] since it is one of their relics and only saints and blessed individuals may bear this staff. 

**Minor Property:** *Decoy.* When the user of this item takes damage, the item instead takes some or all of the damage. It can only absorb a limited amount of damage before breaking or becoming temporarily unusable.

**Special Property:** *Contact.* This item allows its user to contact some powerful entity (most likely the item\'s creator)- or for the entity to contact them.
