#Void 
 

A mask, carved from bones of a intensively powerful being.

It gives off a deeply unsettling, even eldritch feel.

 In case a hollow or bearer puts it on, they'll find themselves unable to remove it and rapidly decay into a vessel, loosing any free thought and speech.


Main use is to be offered to the [[Oblivion Lodge]], or [[The Void]] directly.

 

Cant be traded

Low weight

Medium size


Can be worn as helmet

 

Removes the ability to speak if placed on a completely hollow entity.
