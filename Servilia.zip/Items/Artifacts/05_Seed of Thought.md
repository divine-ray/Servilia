Seed of Thought

Thursday, 28. April 2022

13:01

 

*Player Description:*

A seemingly inert seed from a tree within the Ancient Exile.

*When held:* you imagine how a tiny leaf could sprout from this... you want to plant it.

 

See the Quest:

[**The Word and Thought must spread**](onenote:Major%20Quests.one#The%20Word%20and%20Thought%20must%20spread&section-id={9CCC79C6-7657-FE46-A4C3-AC2899294882}&page-id={26AFDF30-1835-DB45-8070-17265E8C27B0}&end&base-path=https://nswpad-my.sharepoint.com/personal/felixole_lixenfeld_neue-schule-wolfsburg_de/Documents/DnD%20for%20L’P)

*Item Lore:*

It is incredibly thought provoking, and is capable of releasing one's mind from all cultural, social and political restraints.

 

Many ancient books of empires and other non-democracy express a violent fear of these seeds, as they are almost bound to cause coups or revolutions when activated.

 

 

 

**Objective:**

Plant this seed and cause the government of Thylyist to fall.

 

Given from the two Hangmen when listening to their story whilst having:

-   1 fully hollow PC

> OR

-   A high relation to the Undead

 

| Weight | Very low                               |
|--------|----------------------------------------|
| Size   | Very Small                             |
| Value  | *Relic seekers: 25P🪙; Others: refuse* |
