#### Wondrous #Item 
This hollow iron sphere is inscribed with an eye-like iris, and a brass hinge and clasp allow it to open.  
You can use an action to hold the open oculus to your eye and speak its command word.
Upon activation, one of your eyes is drawn into the sphere, leaving an empty socket and dealing 1d4 blunt damage.
While your eye is trapped and you are holding the oculus, you have darkvision out to a range of 5 meters, and can detect polymorphed and shapechanged creatures and objects within 5 meters.
Additionally, the oculus has thermal sight, and can be carried any distance away, retaining a remote view. 
You can use another action to return your eye from the oculus.