#Item 

 The bottle is carved out of gemstone and beryllium bronze and engraved with detailed runes and other arcane writing.

Either acquired by magical item shop, loot, or from within [[Sepulchre]].
#### Item Properties
- Consumable
- Healing 
	- restores 20% HP for Hollow and Undead entities
	- Partially heals or reverses [[Hollowed|hollowing]] state, capable of curing aimless Hollows.


[[Children of The Flame]] could condense some of their cinders or blaze into these, permanently upgrading the bottle to hold more power. (+10%)


Can be refilled at any lit wood-fuelled fire.

Could possibly be unplugged and its fuming content poured into the world.

(Might ignite combustible material)

Negatively affects the Cold and related.

Passively emits warmth, raising character's temperature by up to 10°C (at full charge).

