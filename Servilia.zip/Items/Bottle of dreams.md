#Item #commodity 
Besides my bed i keep a bottle of dreams

Magic component

Somewhat a amarisk condensate as dreams are unfiltered thoughts
