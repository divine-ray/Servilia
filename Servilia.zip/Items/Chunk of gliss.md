#Item #commodity
A decently sized chunk of Gliss, the unnatural substance surrounding the [[Fountainhead]].

Heavy and unusable in its current state, but someone find this highly valuable.

This cannot be worked with regular tools. (Only magic or Laser/water cutting)

Can be sold to mechanics in thylyist, as they value its mass in combination to the absolute lack of friction to it.

They are willing to pay a decent commodity for this unspoken substance.

| Item Size:   | Large         |
|--------------|---------------|
| Item Weight: | Heavy (150kg) |
| Value:       | 1 Vyahn       |

But beware, do not allow the sentinels to catch this!
