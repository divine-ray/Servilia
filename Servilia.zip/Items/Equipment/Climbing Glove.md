
| Item Size:   | Medium |
|--------------|--------|
| Item Weight: | Light  |
| Value:       | 1 Renu |

+1 for unarmed strikes

-1 dexterity

 

Removes penalty for climbing

 

These rugged, made-to-use gloves are adorned with steel claws and knuckles.

They are somewhat clumsy, but you could easily hurt someone with the pointy bits.
