#equipment #Thylyist 
Sentinel power amour, stolen from the [[Central Thylyist Armoury]]. One of the most powerful and strongest marvels of technology available within the era. Highly modular and customizable, talk to [[War Constructor Borange Olbaz]] for upgrades and modification. 

Possession of this asset is condemned, as the Sentinels, and by that extend, the entire Thylyian Military consider this technology top secret and *will* send the Hounds.  

AC: 14, if powered, +7 strength, +3 dex, +10ft

AC: 10 if unpowered; -2 dex -5ft

A finely crafted armour, fuelled by clockwork and steam. With a steady supply of energy it becomes a truly intimidating piece of machinery on the battlefield.
