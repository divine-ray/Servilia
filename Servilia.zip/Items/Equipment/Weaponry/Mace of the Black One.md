#Weapon #Item 
**Weapon (mace)**

**Origin:** *Abyssal.* This item was created by a powerful demon or demon lord from the depths of the Abyss, or a demon cultist or warlock, for itself or to send out into the world and curse whatever poor soul finds it. It is an asymmetrical item made of black iron, flesh, bone, or some unidentifiable Abyssal material, and it bears screaming faces or dark runes. Its powers may cause madness, undeath, deformation or maiming, disease, pain, decay, or something else horrible. It may also be capable of conjuring demons. This item causes any non-demon immense discomfort, and will inflict madness, disease, pain, death, or abyssal corruption on its user.

 

**Major Property:** *Astral.* This item has some connection to the astral plane, such as enabling its user to astrally project.

 

**Minor Property:** *Illusory Appearance.* Illusions mask this item\'s true form. Its user might be able to manipulate these illusions.
