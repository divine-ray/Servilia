#Weapon #elemental #Children-of-the-Flame 

**Staff**

**Origin:** *Elemental Fire.* The item was forged through the power of elemental fire by [[Crimson Heart]]. It is hot to the touch, likely red or orange, and is made from boron steel. It has heat or fire-based powers, and can cause local violations of thermodynamics to source heat.

**Major Property:** *Elemental Cursing.* This Staff strikes its victims with intense, localised bursts of elemental heat, which will burn, scar and cauterise the targeted area, causing horrible wounds that will not heal. Fire or any other heat source in proximity to the victim will attempt to redirect itself towards the subject, as to damage it further. 

**Minor Property:** *Unmoving.* This item prevents its user from being moved against their will.

**Special Property:** *Hungry.* This Staff requires sustenance, charred meat or similarly burnt flesh, and will not function if not fed.

The user gains quite some respect from [[Children of the Flame]].
