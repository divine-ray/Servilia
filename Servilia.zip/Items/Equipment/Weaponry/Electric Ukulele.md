#Weapon 
*And his music was electric.*

Bard's weapon. Any enemy in ranged attack radius will suffer 1d4+2 electric damage per round and 1d6 minutes of paralysation.

Metal armour may provide immunity against these attacks.

Can be used as bludgeoning weapon:

1d6+Strength Damager per attack, 75% to electrocute enemies in ranged attack radius for 1d4+2 damage.
