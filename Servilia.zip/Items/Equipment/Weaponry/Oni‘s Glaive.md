#Item #Weapon
 

**Origin:** *Oni.* This item was created by an oni. It is dark, blue-tinted, and surrounded by a visible magic aura. It is large, but may scale to a size appropriate for its wielder. Its powers are designed to be used by the oni to stalk its victims, and might involve shapechanging, mind control, invisibility, darkness, or stealth.

**Major Property:** *Bulwark.* The user of this item has advantage on saving throws made to maintain concentration. In case the wielder uses both glaives at once, they can draw protective shapes using the blade. 

**Minor Property:** *Traceable.* The user of this item knows its location when it is not on their person, or they can follow the path it has traveled since they last had it. This property may not work if the item is too far away, on a different plane of existence, or protected by abjuration magic or solid lead.

**Special Property:** *Sentient.* This item is alive and can speak to its user or others. It has some amount of control over how it is used and may be able to reject users it deems unfit.

 

Very rare

A lot of value

1d6+3 slashing damage
