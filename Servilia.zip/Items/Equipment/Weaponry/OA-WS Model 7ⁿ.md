#Item #Weapon 

*Origin: Lost.* The creators of this weapon succumbed to the [[Faceless|tooth of time]] and vanished from the face of earth. Only their exquisite craftsmanship in Magitech and weaponry remains. 
Restoration work has revealed the company as "Ommoran Arms Weapons Systems".


A slight modification to a usual handgun is that the chamber is made from a indiscernible blackened metal and the pin seems to be some orange glowing gem or mineral. The glow is faint, but noticeable when the chamber is opened and visible. 

A break-open hand pistol, modified to be capable of using spell scrolls, runes and similar arcane carriers as ammunition. 

Any spell may be loaded into the chamber, given it is shaped appropriately, and fired like a regular shot, which disintegrates the carrier and expels the charge through the barrel and muzzle like a regular projectile. 
Only a few instances of this item remain known and tracked, and are of extremely high value due to their extreme potential in close quarter combat. 
As with its creators, the knowledge on creating compatible carriers and media has almost entirely vanished, leaving the ammunition almost more valuable than the gun itself. 
Depending on the loaded ammo, a single handgun of this series is capable of overturning entire battlefields with a single magazine. 
