#Item

 

Consumable, Healing, restores 20% Stamina and Mana/Amarisk for Hollow and Undead entities

 

Incompletely heals and reverses hollowing state. Not capable of curing aimless hollows.

 

The bottle is carved out of gemstone and Beryllium Bronze and engraved with modest runes and carvings.

 

CoTF could condense some of their cinders or blaze into these, permanently upgrading the bottle to hold more power. (+10%)

 

Can be refilled at any decaying wood-fuelled fire.

 

Could possibly be unplugged and its content poured into the world.

(Might ignite combustible material)

 
