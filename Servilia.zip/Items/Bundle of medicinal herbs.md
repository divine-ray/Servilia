#items


 

Cures one debuff/negative status effect over the course of ... ca 5 min irl time
