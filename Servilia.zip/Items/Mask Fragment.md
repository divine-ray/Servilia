#Void 
Each 4 of these can add +20 HP for [[Vessels]].

Found in the proximity of the Fountainhead and directly in the Void.

'Easiest' way of accessing these is to raid the Ancient's [[Limbo Boneyard]].