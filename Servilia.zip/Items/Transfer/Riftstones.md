#Travel
A small stone, worked to resemble a regular geometric shape.

A glowing, fluctuating coloured line runs over the entire stone, dividing it in two halves.

The merchant provided you with a key which fits into the divider.


It seems to magnetically attract the key...

When the Key is inserted, the cube will halve across the coloured line and open up a temporary rift to any bound location.
Basically acts as a way to quickly return to a place. 

 

 

| Item Size:   | Extra Small |
|--------------|-------------|
| Item Weight: | Light       |
| Value:       | 3 Mang      |
