Disembodied voices telling silent stories through movement. A message from some god(s)?
Dance, rhythm, resonance, able to convey information. March, arrhythmia, tact, devastating. 

Is this magic? 
It is certainly one way for it…