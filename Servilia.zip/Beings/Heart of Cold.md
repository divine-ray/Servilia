#The-Cold #Heart-of-Cold #locations 

Central, vaguely heart-shaped organ of [[The Cold]].
If you're insane, this is the best place to steal tissue from the Cold for creating instances of [[Premature Heart of Cold]].

Located in about the middle of the [[Icy Plains]].

The air is freezing cold, your breath turning into jagged snowflakes, which try to cut you open. 
It has the control here. Your very own blood, your very own water, barely resisting the call to solidify, only held back by your own heart, your own warmth. You mustn't loose heat. 
Each beat, each pulse, piercing and shattering like a artillery barrage. You should not be here. 
It knows you are here. It does not tolerate you here. 
Over there! The whirls in the snow, they are approaching. 
