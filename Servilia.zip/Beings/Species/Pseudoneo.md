The category for lifeforms and beings created by [[The Lavish Empire|Lavish]] scientists as smart, self-directed workforce, typically for tasks outside of their reach of the [[Palga Basin]], and by extend, the [[Astral Ocean]] and [[Sea Major]].
A relatively common, shared trait amongst pseudoneo zoophytes is the combination of higher life, plant life and arcanotechnology into a single, autonomous and self-supplying unit. 

Many pseudoneo beings can source their energy from both biomass/food and sunlight (photosynthesis), whereas electricity or arcane sources are rare, but present.

Through the aeons of creation and experience, the sheer variety of Pseudoneos has led to them being classified as own phylum by modern-day Friscoan researchers. 
*** 
### A List of Pseudoneo life:
#### Sorted based on first known entity
- [[Songbird]]
- [[Dwarves]]
- [[Warped Angel]]
- 
