The soul- and mindless poppet of [[The Void]]. 
Created by outfitting a fully [[Hollowed]] individual with a [[Vessel Mask]], optionally rags, and extreme exposure to Void. 
Vessels are "made" by throwing a masked hollow into [[The Abyss]], which eventually makes them fall into the void. 
However, the void will return the vessel if somehow under full control.

