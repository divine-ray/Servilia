#Characters
Formerly a barkeep in both [[City of Thylyist]] and [[Frisco]], he left these cities behind to seek out his own goals; to take to the sky in trying to be a better man. 
Some would describe him as eccentric, but wholehearted. His exposure to many, many drunkards clearly shaped him, and he wishes to make up for what he (indirectly) brought to these people. 
When he left Thylyist he sold all his other possessions to get hold on a wreck of a airship, which he meticulously repaired into his flying home. 
Ever since he almost constantly travels the lands in his belief of spreading a greater good through performing courier services and transporting people and goods. 
However, he chooses his customers and goods carefully, and only agrees to transport them if it meets his morale standards and ethics. Outside of this, at times arbitrary, selection process, Daniel is very reliable and happily seen on airports. 

Content but unfulfilled he seeks to find a goal in his life beyond delivering goods and people.