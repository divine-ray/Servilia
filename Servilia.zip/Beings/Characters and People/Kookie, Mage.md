

Lives in [[Lavish Wastes|the Wastes]], sells magical items and is knowledgeable about the lavish.

One of the few people who have fragmented knowledge about The Fountainhead.

Dragon-breed (Silver), which allows them to adapt to the Chaos and other perils of The Wastes

 

Is slowly being corrupted by the Chaos and Between leaking...

Is already heavily weakened by the effects of the Void, and bound to perish soon, as he has passed all stages and is seen as terminal. 