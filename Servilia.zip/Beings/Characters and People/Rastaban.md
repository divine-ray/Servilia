The machine, a killer. 
Relentless, driven by cold programming. Cruel and efficient. Rejected its [[War Constructor Borange Olbaz|creators]] and slaughtered them. Wrath incarnate. It only finds peace in war, beauty in destruction. 
It remains undefeated. 
A winged behemoth and harbinger of death. Its shape, a cruel mock-up of the renown dragonkin. 

Lay waste to those who oppose us. 
That is the instruction. All of Thylyist's borders have been put to waste. 

The protector. Defender. Terminator.

This is what Death is, given a Machine. 