
A trio of legendary adventurers who haven\'t been condemned to the Ancient Exile.

Motives unknown, but rather present in folklore and song.

Despite the telltales saying them to be dead or missing, they\'re still active and out there.

Their trio is welded together shut, working flawlessly together, said to be able to overcome any obstacle. 

Soldier: 
	"There will come a soldier  
	Who carries a mighty sword  
	He will tear your city down"

Poet:
	"there will be a poet 
	who\'s weapon is his word 
	he will slay you with his tongue\"

King: 
	"There will come a ruler 
	Whose brow is laid in thorn  
	Smeared with oil like David's boy"
