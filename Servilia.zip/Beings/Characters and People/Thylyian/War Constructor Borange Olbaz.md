

 

Offers modifications for Thylyian Weaponry, when in disguise.

 
