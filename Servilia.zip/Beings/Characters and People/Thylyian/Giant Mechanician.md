#Thylyist #Merchant

Sells all kinds of mechanical components and such

 

Incapable of detailed speech, mumbles all the time

Mechanically augmented

 

> WILL provide some lore about Thylyian mechanic and that history n stuffs
