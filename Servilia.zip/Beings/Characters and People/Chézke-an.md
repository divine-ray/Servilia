#Undead 
 

Ancient lich. Plots to conquer the [[Sepulchre]] for harvesting the undead population.

Formerly a warlock, signified by the -an suffix.
