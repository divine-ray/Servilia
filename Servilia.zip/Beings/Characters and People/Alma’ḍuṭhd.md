
Was hired by the [[Lunatics]] to "recapture" [[Serpensyll]].

His moral compass is severely damaged, ruthless towards his targets

The Party may choose to either work with or against him.

He is a half-orc and is very scarred.
