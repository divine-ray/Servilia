#Ancients

 

Marilee was once a widely renown and respected singer, who had secretly used magic to bring motivation to the people, especially those bearing the[[Curse of the Undead]].

(She sorta adapted Cant into a sung form)

During her time, she ascended into almost being the guardian patron for the Cursed Undead, which drew the attention of the [[Children of the Flame]].

-   She has become Patron or Deity of Song, assisting devoted Bards.

 

After several fatal attempts of the Children on her and the then-necropolis she got lethally injured and reached out to the fabled Cold, to heal her and to give a counterweight.

Unfortunately, she was unaware about how [[the Cold]] functions and thus she did not prepare for its overtaking nature, and got completely frozen.

 

Existing in this unnatural state, most townsfolk rejected her and Marilee's popularity plummeted. The only few who still enjoyed her singing and such were the inhabitants of [[Sepulchre]].

 

She then caught the attention of a ancient, whom was tasked or devoted to guarding Sepulchre. That ancient invited her over to the Exile, in attempts to combat the leeching Cold.

They couldn't help her either. This disappointment in "the gods" caused her to finally snap, falling into depression and sorrow.

She has given up herself, singing her song of sorrow and melancholy on a lone peak within the exile.

Some air elementals have picked up her story and song and are distributing her song across the realm, to those who want to listen to it.

 

-   ghost winds may carry her song

 

*On encounter:* the party may give her a last audience and end her suffering via death.

-   (Inspiration and motivation buff for 3d6 days)

*Or:* if one of the party members are Cursed or Ashen and thus carries Bottled Embers, they may offer her some (1d6+1) Embers and combat the Cold, which will give her new life force.

-   (Ability to learn sung Gradam Cant, notable reputation increase within Sepulchre, re-buff for bards)

 

© Levy

 
