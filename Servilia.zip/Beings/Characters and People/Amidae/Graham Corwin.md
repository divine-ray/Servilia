Graham has white dreadlocks and amber eyes. He wears a white suit and a black leather trenchcoat, and carries a switchblade knife. 
Graham is being hunted by protoGen Industrial Group for AI murder.
