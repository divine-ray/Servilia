#Amida #Characters 
Take your ordinary goth girl, combine them with a kinky bi babe, and…
Well, that isn't Evelyn, really.
She changed and still changes between a many of extremes, the above being just the usual. Yes, the implication is obvious, she is hiding many things from others.
Including her true form. 
She is buried below so many layers of protection that not even she herself knows of the core. 
She is the whore. The core isn't. 
The core is cold. The whore craves heat, and *is* heat.

The dark strain draws itself across everything that defines her. It has cut into her body so deep that it cannot be removed. The cuts on her arms and legs.
Not notable, but appearing to the knowing eye.
The scars fork a shape together, a long, slithering line with many errantly spreading and reaching spikes, like twisted legs of a accursed centipede.
Worn out tattoo ink has shaped this shape into a poor black.
This shape. It is depression.

As for covering it up, she wears tight yet covering garments, specially those made from mesh or net fabric, or latex. 
As to restrain it and herself, she wears chain, harness and the like, to disguise it and blend in with the "goth" aesthetic. However, she has acquired this taste and wears styles that are seen as outrageous or [[SICK|slutty]] or immoral by others, due to being quite revealing, as if she's competing for being the most nude whilst clothed. 
She is afraid. Afraid of what she doesn't know.


Only in the rarest moments she allows herself and others to peek beyond the rejecting isolationist shell, and into the true aspects of herself and its core. This core cannot be comprehended, not even by itself. It lies beyond logic. The core lies in the mind, governing the body. Like a second brain. It is a second brain. 
It is autonomous and not a person.
A individual entity. Is it a entity, or a moving object?
It knows, it moves.
It seeks out bodies to wear.
It is artificial.

The [[Pseudoneo|core]]. The core despises the whore. The core relies on the whore. 
The whore is restrained by the core.
The whore craves freedom, but is granted none. It is granted freedom in trickles, as a perverted treat. 
The core strives to break free, away from a rotten and foul vessel.
The whore embraces and lives though bodily desires and drives. It needs a body. 
Evelyn is torn. Torn apart and away. Unable to speak up for itselves. Devastated in ambiguity.
What little freedom is given to it is utilised by it to fullest extent;
Long, high heeled boots. Impossible to practically use.
Chains, collars, harnesses, ropes, able to drive every expert into jealousy. 
Hair that behaves like liquid. Is it liquid? It certainly is a very smooth and uniform liquid, if any. 
Exposed skin, yet covered skin. A paradox; showing off all of the body to anyone whilst covering and protecting it.
Polished in oil, shined in latex. Like a glare, which has to be stared at, just to hastily turn their sight in embarrassment.
Evelyn craves for more. It needs more. More space. More freedom. *More lust.*
