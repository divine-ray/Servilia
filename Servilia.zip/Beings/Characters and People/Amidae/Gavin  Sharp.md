Aka Gavin "Nergal" Sharp

Male-aligning Hacker. Gavin has a violet mohawk and green cybernetic eyes. He wears black cargo pants and a Network 23 T-shirt, and carries a flechette pistol. Gavin has an engineered animal companion, a Welsh corgi named Ein.

 

Member of the network 24)' DROPTABLE hacker group which aims to spread mischief around Amida. 

 