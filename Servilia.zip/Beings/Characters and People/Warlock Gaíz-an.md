#Characters 
They have stolen knowledge about the Limbo Boneyard, and embarked on their quest to return the masks to the void.

They lived long enough in the proximity of the fountainhead to be highly deranged and insane, and believes that the void is right in its motive to annihilate the material plane.

Founding person to the [[Oblivion Lodge]].
Their first sacrifice to the void was their gender, they are now a gender.
