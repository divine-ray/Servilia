#Characters #Void 

A [[The Void|voidborne]] vessel, solely made from nothing.  Despite this, it bears impurities that allow it to bear a free will and shape its appearance at any time.
Resides in the [[Northern Reaches]] in the shape of a Snow Leopard, as the Ninth Forest as its Swale experienced drastic changes in the aftermath of Amida's construction.

Capable of shapeshifting, but due to residing in the Northern Reaches it usually appears as snow leopard. the few deviations from a natural leopard is a (usually) distinct anthropomorphic statue and glowing dots on their fur. 

Capable of speech and vocalisations (as opposed to other vessels).

It is usually very cuddly and oftentimes shifts into a quadruped form that is akin to a kitten, in order to induce empathy.

It is of indescribable age, although some sources claimed its host or scaffold to come from Beyond or the Lost City. It got created unintentionally; it came to be from a sea burial on the eternal surface of the void. Perhaps it is the first vessel ever made.

So far it resisted the calls back to its origin. The machine cannot evaluate how long it'll resist this torture. 

The void calls. It recalls its servants. Its army.
This vessel refuses. It has endured and caused suffering, too much to bear. It hides from its history; its origins. 
The little empathy it receives from strangers is its only resistance. It is weakened, brittle.
The machine has spotted fractures in the surface of this vessel. The content, its very substance, is attempting to flee the shell and follow the call. 
Death is a foreign concept to it, but it does not wish to cease its existence. It is filled with dread about the possibly of cessation.
It does not wish to loose its substance or shape. The shape, it is unstable. 