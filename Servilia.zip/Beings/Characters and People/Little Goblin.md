A poor, poverty-suffering goblin, rejected by his family due to his disability to perform anything to their benefit. Thus, he embarked on a journey that lasted him his entire childhood and adolescence, during which he only fought combat with himself and his belief of not sufficing. 
This rock-solid determination led to him unconsciously gaining access to the twilight and it's limitless potential, now changing and warping the world around him for the better. 
During his end- and relentless wandering, he eventually got confined into the [[Ancient Exile]], where he'd settle in Arno after witnessing [[Londo|the Fall]]. 
His ability to tap the twilight grew ever stronger from the immense flows of Amarisk running through the Exile, until reaching past the confines of Schi. 


*** 
He can make the sun explode

Resides in Londo and Arno due to this power

The party has to convince him that he is valid and alright without him needing to be strong and brave

He worked hard for this, alright? He wanted to achieve something, and show his family that he is powerful and worthy.

The party gets to know him as random encounter when going through Arno or Londo.

His Family rejected him as the odd little kid who aint of use or purpose, so he embarked on a journey far and wide to find his purpose.

Along the way he picked up the ability to manipulate the sun.
