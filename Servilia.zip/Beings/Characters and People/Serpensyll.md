A misled summoning of [[The Navigator]] by the [[Lunatics]].
Sucessfully escaped the lunatics and is now chased by [[Alma’ḍuṭhd]].

 

<https://www.dndbeyond.com/characters/76105111>
