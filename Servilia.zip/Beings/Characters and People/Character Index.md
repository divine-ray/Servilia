
##### #Beyond 
[[Darb ut-Tabānah]]
Time
[[Schi ut-Pula]]
[[Queen of Shadows]]
[[The Navigator]]


#### #Thylyist 
[[High Engineer Kzhan II]]
[[War Constructor Borange Olbaz]]
[[Giant Mechanician]]

#### other 
[[Marilee, the Songstress]]

Kookie

[[Daniel]]

Nameless Goblin

Alma'duthd

Soldier, poet, king

[[Serpensyll]]

[[Warlock Gaíz-an]]

Juno

Maou'oru

### #Amida 
- [[Gavin  Sharp]]
- [[Graham Corwin]]
- 
