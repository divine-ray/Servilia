Blatant self insert.

Depressive deity that made the world, but sold it to some unrelated entity.

Their depression allowed for the plague that we call the [[Curse of the Undead]].

Often seen as careless by the other pulastaya, but not out of malicious intent but rather disregard and lack of a healthy relation and position.