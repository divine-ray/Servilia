The Queen of Shadows is a being from #Beyond who rules over the shadow realm.
She's a #Shnūt , to be precise. 

She appears as a infinitely long and massive worm, which is merely constructed from a many floating rings that, given the nature of this realm, eventually trail off into the darkness. 
The front end shapes as several shield shaped segments orbiting a ring, mimicking chelicerae. 

Involved into the eternal fight of light vs dark as both the victim and offender.
She defends the shadow realm fiercely against intruders and foreign beings, but cares for her kin and residents wholeheartedly.




