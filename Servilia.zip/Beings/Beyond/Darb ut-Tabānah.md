#Ancients #Tabañaya 

Former Resident of [[Londo]], witness of the Fall of Londo to [[Vessels]].

Despite bearing a mature iteration of a [[Premature Heart of Cold]], they got killed in that raid.

This unjust death caused him to get reborn as widergänger, with the purpose to fight the cause of the loose vessels.

Thus, he is fighting to get into the Thylyist Council (as they are versed with technology and are disliking supernatural powers), and to manipulate them into combating the Void.
	He is trying to get the party into dealing with the [[Fountainhead]], with the goal to seal it.

He doesn't know about the [[Oblivion Lodge]], and it may be best for the party to tell him.

Darb ut-Tabānah is seemingly blaming the more ignorant folk within the [[Ancients]] for the raid on New Londo.

>Welcome, moon and star, come to me, through fire and war, ooh, ooh.
>Come, Nerevar, and look upon the heart, upon the heart, ooh, oh.

Associated to the [[Lunatics]] due to being a #Tabañaya , the Child of [[Darb]].
