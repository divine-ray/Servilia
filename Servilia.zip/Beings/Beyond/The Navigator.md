Disembodied #Shnūt , manifested concept of navigation using stellar constellations. 

Usually benevolent towards travellers, aiding their voyages. adored by many (past) civilisations as deity of travel.

It's capable of altering starlight to guide and influence people. This is especially noticeable in [[Amida]] as the current space-faring vessels navigate using constellations. 

Perhaps discovered by the #Lunatics . 
[[Serpensyll]] is the product of the lunatics trying to force a fragment of the Navigator into a vessel.