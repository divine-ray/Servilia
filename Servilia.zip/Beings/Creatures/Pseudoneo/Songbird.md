Airborne bird-mimicking automatons, among the earlier attempts of [[The Lavish Empire|Lavish]]  pseudoneo life.
Widely employed around the continent, and have gained civil (outside of Thylyist) recognition as more reliable and effective messenger birds. Larger instances are very much capable of carrying larger goods and other beings, in rare cases even whole carriages. 
Highly modular, which is part of their widespread presence. 
The first and last pseudoneo species with higher degrees of freedom and self-improvement. 
Being aware of their nature, a group of songbirds, the [[Avian Renegades]], split off from their driven-in servitude and moved on to form their own, wandering, society. 

The Lavish gave them the ability to reproduce... Through which means their control has now, after aeons, faded. 
[[Dwarves]], as another part of the pseudoneo phylum, have been manufacturing Songbird components, as to support their modularity. 