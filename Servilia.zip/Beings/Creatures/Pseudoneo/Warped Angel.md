#Creature #Pseudoneo  
A divine guard of the ancient exile. Created by the [[The Lavish Empire|Lavish]] and [[Ancients]] in a joint effort to protect the [[Ancient Exile]] from further attacks, especially after the Fall of [[Londo]].

Usually someone will only encounter the airborne aspect, as the grounded aspect is hidden. They cannot exist without another, but the airborne aspect channels great powers to defend itself and the Exile. Without the grounded aspect, the anchor, both will perish. The anchor is the source of its power, the airborne is merely the outlet. 
Nor is the anchor a marine anchor, it is flesh and mass fused together, sessile onto the ground, passive and rather much like a displaced anemone made from gore. 

Barely resembles a angel as per the common image, rather, wretched wings onto a malformed humanoid body, its limbs torn to shreds at the tips through the excessive energies it is conducting. 

One might obtain further knowledge upon taking the lethal risk of close study, or from Archives of Old. 


***
Attacks with fast-firing light rays or heavy orbs that inflict hollowing.

They attack on sight and are otherwise docile.

They ignore the party if they have a good standing with the Ancient Deities.

Med 🛡to ⚔️🏹

High 🛡to 🔥

Weak 🛡 to ⚡️

Languages: Celestial, Ancient (telepathy 24m)
