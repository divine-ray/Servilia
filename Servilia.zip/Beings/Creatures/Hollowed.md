#Undead #enemies 

A poor undead fellow who succumbed to the [[Curse of the Undead]].
 

Most of them are located in the infirmary of the Necropolis.

Some make weak attempts to attack their environment in their deranged condition, dealing 1d4-1 unarmed strike.

 

Some roam the Realm aimlessly due to lacking a motivation

 

They can get helped if they get provided 1x [[Bottled Embers]] from any NPC or PC.
