
A curse or other [[Fall|misfortune]] has driven these poor people insane, yet not letting them die.
Possibly hollow or undead people which have lost all mental integrity.

Upon careful inspection, you recognise their catastrophically degraded mental condition.

Maybe you can try to help these lost fellows?

 Their faces are covered in long and poorly-healed scars, likely sourcing from scratching themselves with their horribly elongated nails that resemble talons or claws.
 Their hair is also extremely mistreated, as with the rest of their body. 
 
They can be heard chanting this in a sobbing and deranged manner, as long as they don't perceive someone else:

	I am tired of punching in the wind  
	I am tired of letting it all in  
	And I should eat you up and spit you right out  
	I should not care but I don't know how  
	
	So I take off my face  
	Because it reminds me of how it all went wrong  
	And I pull out my tongue  
	Because it reminds me of how it all went wrong  
		
	I am sorry for the trouble, I suppose  
	My blood runs red but my body feels so cold  
	I guess I could swim for days in the salty sea  
	But in the end the waves will discolour me  
	
	So I take off my face  
	Because it reminds me of how it all went wrong  
	And I pull out my tongue  
	Because it reminds me of how it all went wrong  
	And I cough up my lungs  
	Because they remind me of how it all went wrong  
	And I leave in my heart  
	Because I don't want to stay in the dark


If they are addressed or possibly threatened, they will stop chanting and resort to self harm, which also injures any people observing them within a ca. 9m radius.

Those "methods" are the ones mentioned in their chanting.

*All of them remain until respawn or full heal:*

-   *Faceless: unable to communicate to NPCs*

-   *Tongue removed: unable to speak*

-   *Lung coughed: Immediate Death, reduced air capacity*

 

Answering them with sung Gradam Cant is likely (1d100,x\>40) going to calm them, and some lore will be revealed.

Singing to them with [[Marilee, the Songstress]]'s blessing will ease their mind and they can be spoken to without issues.

(Their mental state is still pretty broken, and on the development of a toddler, 3yo.)
