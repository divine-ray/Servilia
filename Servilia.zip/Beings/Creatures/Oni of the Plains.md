

A massive fellow who guards the [[Palga Basin]] from unwanted intruders.
Origin unknown; likely arrived through the twilight after the Fountainhead broke down.

Wields 2x [[Oni‘s Glaive]]
