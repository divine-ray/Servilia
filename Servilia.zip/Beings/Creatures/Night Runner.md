

 

Void-born Creature, docile unless provoked or perceived.

Usually hides within shadows around the Hollow Mountains and The Fountainhead.

These appear during nighttime and will likely assault exhausted travellers and the resting.

 

Passively inflicts psychical damage and increases Insanity.

1d6+n psychical damage, n being insanity.

These are likely Vessels without Mask which are loose and running wild.

 

Understanding Celestial and Abyssal makes them directly addressable (100% chance) and allows the player to understand them. Still increases insanity.

###### *Possible quotes:*

-   *Come Home.*

-   *Void is Home.*

-   *Ease your pain, follow.*

-   *Lost child...*

-   *Do you feel lost?*

-   *Come along..*

-   *All these nightmares...*

-   *Make them escape...*

-   *Fly away.*

-   *Relax...*

-   *It's just a dream...*

-   *Wake up...*

-   *Don't see*

-   *You cant see*

-   *Turn away*

-   *Theres nothing here.*

-   *Run.*

-   *Don't go further*

-   *You are not wanted here.*

-   *Stop.*

 

 

Carrying any Vessel components (cloth, mask) will gain their attention regardless of position and such, and they will attempt to acquire the components for themselves.

> Respawns

Cannot be killed by 🏹⚔️

High 🛡 to any damage

 

Directly addressing these with names may turn them docile again.

Spoken Magic and Grandam Cant is highly effective and makes them vanish.
