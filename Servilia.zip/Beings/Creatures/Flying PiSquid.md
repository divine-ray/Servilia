#Creature 
A winged squid that haunts the sea around the Thylyian coast.

Any perception of it is obscured to mathematical formulas that always include pi as solution or component.

 
Can be tamed as a companion or mount


> Respawns
