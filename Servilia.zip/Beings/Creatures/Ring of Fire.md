#enemies #elemental

Tormented fire elementals, corrupted by the pained twilight and sweeps of void.

Only present within the wastes, most commonly around hot spots.

Easily defeated by water or by casting them into a suitable vessel.

\*raises the environment temperature for a single being/victim by 5°c per round.

 

\"A group of small ember flames arise from the ground, encircling you and rapidly grow larger.\"

\"you begin to sweat massively. Soon the heat becomes unbearable and your body begins to blister and char.\"