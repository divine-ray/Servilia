#enemies #The-Cold #Northern-Reaches 
Some canine that fell towards [[The Cold]]. 
Preferred food by [[Will]]

Almost a cube walking on legs, some spiky bits of fur standing off