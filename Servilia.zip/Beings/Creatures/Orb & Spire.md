#enemies #Creature #construct

A bunch of perfectly spherical objects, inert from a distance.

Assemble into a spire when approached, attacks when engaged.

2d4-1 Atk blunt or bludgeoning damage per hit.

Usually located around Druidical or otherwise nature magic places.

> Respawns
