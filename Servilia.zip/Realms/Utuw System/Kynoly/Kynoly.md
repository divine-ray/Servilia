moon of [[Schi]].
volcanically active and hot, presumably a captured protoplanet.
