A earthlike planet, outfitted with rings and three moons:
-  [[Heaugi]]
- [[Opar]]
- [[Kynoly]]

The only habitable planet in the [[Utuw]] system.
Was or is home to several sentient and complex species:
- humans 
- dwarves
- dragons
- elves
- lavish

###### 0.13AU away from Utuw 




