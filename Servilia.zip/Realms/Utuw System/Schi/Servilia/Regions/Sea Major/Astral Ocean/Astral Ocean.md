#Regions 
This ocean is a gem in itself. Any blockade in seeing the sky is counter-obscured and makes access to starry skies possible at any time, even during the day.

This region is seemingly capable of reading minds and works as telescope and magnifier to show figures and constellations to symbolises something. It has become invaluable to astronomers and [[City of Stargard|stargazers]] alike to take deep peeks into the universe.

As aforementioned, it actively filters out sunlight to keep a better view but modifying any other light sources (distant stars and the moons) to average out the compensation of lack of light. Because of this, this region is nowadays home to many odd and unique beings, which shape a eccentric but thriving ecosystem.

Due to it's sheer size its impossible to appropriately map all underwater regions, and thus only the land areas are mapped, eventhough sparsely.

 

First of which area is the lunar mangrove forest, which spans a fair share of the coast to the Ninth Forest. It's covered on a own page, as it is a too complex ecosystem to cover.

 

 

 

