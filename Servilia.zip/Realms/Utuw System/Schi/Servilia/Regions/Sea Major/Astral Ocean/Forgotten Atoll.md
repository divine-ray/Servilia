

Not too far away from the [[Chromatic Calderas]] is a cluster of atolls, which are common residence to

Antares. This area is differing from the rest of the ocean itself, as only dead and distant (from outside the milky way) shine. This usually confuses seafarers who orient themselves on constellations.

Additionally, the atoll easily obscures one's mind, lightly acting as anti-memetic effect.

 

*Antares*
