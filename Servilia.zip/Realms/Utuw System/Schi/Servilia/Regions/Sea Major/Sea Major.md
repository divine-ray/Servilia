#Regions 
The ocean that stretches the entire known world. Transitions into the [[Astral Ocean]] around the northwest coast of Servilia.

Flavour Text: "Alone, at the edge of a universe, humming a tune. For merely dreaming we were [Snow](onenote:Major%20Quests.one#Introduction%20to%20the%20Snow&section-id={9CCC79C6-7657-FE46-A4C3-AC2899294882}&page-id={7DC18E75-15F4-8942-B891-E0FE4496F6A2}&end&base-path=https://nswpad-my.sharepoint.com/personal/felixole_lixenfeld_neue-schule-wolfsburg_de/Documents/DnD%20for%20L’P)..."

 

A stretched out area of islands, home to all other dragons that don't reside in and around the Hollow Mountains (and spine of the world).
The central island group [[Kaá-Rav]] features a series of mountain peaks, as the other end of the massive proposed rib cage to the spine of the world.

Also resident place to the lunatics in stargard.



Eventually fades over into [[Edge of hope]].