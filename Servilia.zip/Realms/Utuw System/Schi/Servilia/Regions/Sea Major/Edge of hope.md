#Regions 
The 'edge' of the known and mapped world. Refered to as the edge of hope since no-one who ventured further returned ever since, including dragon scouts. 

This Region marks the seam of the Servilian tectonic plate, covering Kaa'rav and the isle of Northern Reaches. 