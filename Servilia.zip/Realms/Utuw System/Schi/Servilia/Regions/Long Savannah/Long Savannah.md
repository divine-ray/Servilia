
Vast and extending plains, found to the northeast of the hollow mountains.

Former home to the Lavish Basin, now known as the Wastes.

 

Dry and arid, the opposite of the dense forest that covers the upper-left of Servilia.

Seemingly devoid of life, but few scientific expeditions have been made here yet.

No signs of intelligent life have been found here, either, other than the remains of the Lavish.

 
