#ruins #Lavish 

Old, derelict ruins of [[The Lavish Empire|unknown architecture]] and materials, from within a deep basin. 

 

You can sense some eerie sensation coming off it.. You are not welcome here.

Every part of these buildings is telling you to leave. 
Like a beloved one on the deathbed, wishing for a last silent moment. 

Nearly everything has been raided and stripped down to the very raw frames.
Where once were imposing, towering buildings are only crooked frames. 
It all has been swiped clean by the scavengers. 

There is nothing valuable here.

Leave.

 

*If magically attuned:* you feel a chaotic, yet even primordial pulsing...

*If clerical:* you feel a unholy presence nearby...
