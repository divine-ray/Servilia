#areas #Lavish 


Was previously the capital of a nation of magic-affine molluscs, [[The Lavish Empire]].

 

TODO: Rumours about The Wastes

Nicknamed "The plains of Lavish" by adventurers and alike

"Lavish" has succeeded as nickname.

After The Brotherhood Backstab, all water got evaporated and dried into salt, which got corrupted into Gliss by the lingering chaos and energies from the FH

They got nuked by the arcanophobes of Thylyist

 

No one except the Archives of Thylist knows about what happened here

Some Chernobyl like liquidators have set up forests of spikes around the edges of the flat, to deter people.

Approximately in the Centre of this giant flat is a opening, The [[Fountainhead]].

The only somewhat remaining Structure is the FH 

Basically theres nothing of value here except... nothing. All got raided over the years.

Except... the raw Potential of Vis that can be tapped from The Fountainhead...

 

> If they manage to actually tap it lol

 

The shit that came from the Fountainhead aided in their downfall
