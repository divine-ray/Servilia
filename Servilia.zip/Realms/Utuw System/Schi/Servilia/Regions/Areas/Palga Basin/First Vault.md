#### #dungeons
 

**Location**: Salt Flats of The Wastes.

Approx. 5km northeast of the [[Fountainhead]].

 

**Dangerousness:** Lethal.

(**C**reatures-**T**raps-**E**nvironment)

-   Low level creatures, mostly carved out Cursed.

-   Automated security systems, turrets, weak and rusty.

-   Extreme environment level, but the vault provides shielding.

    -   High Ionising radiation, bubbling chaos, lurks of void.

 

**Possible Loot:**

(**E**quipment-**V**aluables-**C**urrency)

-   Up to 60 HazMat Suits, full sets.

    -   Gas Masks

    -   Geiger counters

-   Silicon technology pieces and scraps, sums up to.. High 🪙

-   Lavish Currency. Worthless to Thylylians.

![[First Lavish Vault.png]]