#Twilight #Void #locations #Ruin 



 

This is basically a interdimensional drilling rig that leads to [[The Twilight]] and thus the void.
The borehole is physically accessible
 

And now that the [[The Lavish Empire]] aren't here to maintain the catalyst of the fountainhead the whole Between creatues (and -energies) come crawling through the wastes, turning everything hollow


> #QUEST: retrieve the Catalyst from ??? And repair the Fountainhead
>
> #QUEST: Destroy and seal the Fountainhead

 


The Wastes around the FH have become gliss, a substance with close to zero physical properties, thus, no colour or friction

![[Media/image002.png]]