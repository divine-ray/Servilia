

When completely delved through [[the Twilight]], people could access [[The Void]].

 Acessible through the [[Fountainhead]].
 The Voidfish is this plane's #Shnūt .

Supposedly only [[Vessels]] or hollows can stay here without being torn apart and going insane.

Hollows quickly turn into vessels when contacting the Void.
