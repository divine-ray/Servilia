#locations #Lavish 

#SC-AM Super-collider Antimatter power project
Lavish-built super-collider with four major cylindrical towers for stabilisation
Multitudes (256) of automated cooling ports placed around the ring, which pop up once a day to gather atmospheric nitrogen and dump accumulated heat
	→ mysterious rock movement and heat deaths
It's still[^1] in operation and fully maintained by [[Pseudoneo]] entities, which are highly valued by scavengers
The ports and towers are overgrown and concealed with rock, soil and plants, but they're somewhat noisy (but most beings don't perceive this noise yet avoid them still)
The collision chamber is under the #Ancients exile as safety measure
The #SC-AM project is top secret and partially outfitted with antimemetics.

Its power signature eventually got discovered by Amidan Scientists, so its power output quickly got redirected after the Fountainhead was dealt with. 



[^1]: including Amidan future
