#Children-of-the-Flame #Ruin #dungeons #Cult   


Running up [[A Hill]], it has a lonely castle, set to rot and salvage.
It's roofing, originally copper, has been completely torn out, and some sections have been demolished.

Former Elven stronghold, destroyed in the genocidal sweep of Thylyist bombing the Lavish.

Leyline node due to the souls of unrighteous deceased inhabiting it, which partially feeds the Children.

Headquarters to the [[Children of The Flame]]. Epicentre of the [[Scorched Acres]].


Otherwise Home to a few hollowed elfs, who get supervised by benevolent gnomes/gremlins

