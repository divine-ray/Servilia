
A place where magicians and mechanists alike dumps their unused or mishaped creations.

**Location:**

**Dangerousness:**

(**C**reatures-Traps-**E**nvironment)

-   No monsters

-   Dysfunctional Spells and Machinery that can discharge

-   Some wastes and chaos

    -   Actually a temporal anomaly that attracts waste and scrapped things through time

**Possible Loot:**

(**E**quipment-**V**aluables-**C**urrency)

-   Bag of puppies

    -   Glass cannon

>  

 

Wien 281097
