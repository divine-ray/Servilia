#locations 

A hill that manifests on a random grassy plains once any full moon.

If one runs up that hill after the night it appeared, they can make a deal with "god", to change the bodies of two NPCs or PCs.

Said to contain physical remnants of a deity or other powerful entity...