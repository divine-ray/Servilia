#Lunatics #Settlements #Faction 
 

A bunch of isolated and deranged sorcerers who devote their time towards celestial bodies.

The only remaining actively practising guild for Astral Sorcery.

 Home to the aptly-named [[Lunatics]].

They are somewhat able to predict future events by calculating celestial body alignment. Through this, they saw *things* that took their sanity.

 

Some of them replaced their eyes with crystalline lenses, designed to view the sky.

Highly afraid of light, and nocturnal.

At times they scowl at the sheer mention of light.

 

Situated on the southern island, where usually the dragons do their things. They just don't bother each other, and that's how their peace has been kept over centuries.

They can offer valuable information if their babble and insanity can be deciphered.
