#locations #ruins #dungeons 
 

A overgrown city, situated in the [[Ninth Forest]], [[Fall|laid to waste]] and rot long ago. Perhaps another victim of vessel raids?

This place has been dubbed Tombstone by explorers and scavengers, as its perfect disassembly draws parallels to the masonry on a tombstone. 

Inspection reveals that most buildings seem to have disassembled themselves, in orderly disarray 
-   Bricks missing
-   Things lacking in places where they should be

*With good perception:* The entire area is loudly screaming "LEAVE AND DON'T RETURN"

The roads of this place vaguely shimmer in golden tones

Inhabited by [[Faceless]]

 
