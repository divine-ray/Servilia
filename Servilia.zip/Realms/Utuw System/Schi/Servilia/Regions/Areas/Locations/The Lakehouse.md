#locations #Ruin 
 

*A big, chaotically built mansion, towering over the nearby lake.*

*It emanates a warm and homely feel. Maybe you want to come inside?*

This mansion or house was built long ago by now long forgotten noble people.

They seem to had powerful knowledge over arcane architecture, as the entire building seems to be capable of sensing its environment and inhabitants.

 

It's build on a strong, almost untouched stone foundation.

Closer inspection reveals that every material is in a similar state to the foundation, seemingly directly put into place without further manufacturing.

*Upon casting a spell or working magic within:*

> Something is off... you don't feel the usual exhaustion coming with magic.
>
> What was that?
>
> Did the floor panels just... flap?

 