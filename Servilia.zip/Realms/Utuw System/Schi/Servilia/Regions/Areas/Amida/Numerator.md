#Amida 
Big if not titanic semiorganic and sentient supercomputers that search for a solution for the [[Curse of the Undead]]. Their enrire structure houses sectors each and districts of Amida and they govern infrastructure.
Numerators were able to interact with the control of the [[SC-AM]] project and tap the power output for [[Amida]].
Most of the heat produced is absorbed by purposed [[The Cold]] tissue to recuperate energy and not to devastate the environment like Rainworld
Yet again, [[The Cold]] tissue is highly contagious and secured in the core of each numerator, as they're partly built from Cold.

Strands and bundles of neurons and veins facilitate most matter and information (including civilian) transport within each numerator.
General population is aware of the rough task of the numerators but they don't really care other than for housing and supplies. 