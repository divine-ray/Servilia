#Settlements #Faction 
The only other noteworthy human settlement besides Thylyist. 
Central railway node, since the Friscoan built most if not all of the [[Servilian Railroad and Train Network]].

Economically strong due to being central to trade, travel and business. Rather capable of competing with Thylyist, thus repeated victim to the [[Dogs of War]] in attempts of sabotage. 

Their [[Duley and Port|development]] is seemingly stuck on the age of late industrial revolution to early accesses to electricity, yet no major fossil fuel usage is employed (oil). Coal and steam remains a widespread power source for industry and locomotion. 
Sailing ships still reign supreme in their naval trades over at [[Brisburne]] Harbour. 


They possess a unfinished [[Argrosy]] station, and are only half-aware of it. Some spelunkers and excavation teams have repeatedly ran into it, but left it untouched, unknowing what it is. 