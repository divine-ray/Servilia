#Settlements #locations #Travel 
## Airport and trade hub in the [[Frisco Bay]]


Duley and -Port is the scientific driver of the Frisco Bay Federation and central to the region's aerial transport. 

It is known for its many open plazas and squares, plated with bronze and copper, same as the roofs. 
Many of these squares are long and rectangular, allowing smaller, winged aircraft to land and start from them. 

Buildings here are typically two storeys high, and usually have at least one cellar layer. most cellars are interconnected through neighbouring secured doors and tunnels, which shape secondary means of transport. 
The biggest tunnels here have a whopping four lanes, two each stacked upon each other. Ventilation usually poses a hassle though, but early experiments with electricity have shown to be promising. 

A bit out of the central area is the namesake Port, where airships and other updraft based vessels dock. This port is constructed from sky scraping towers, which extend in many directions on several layers to house the notable throughput in goods and people. On the ground, in close proximity to the centre, lies the Duley Grand Station, which provides means to rapidly travel to Frisco to access the Servilian Railroad. 
Cargo transfer is provided close by, and only little away. 