 #Thylyist


Capital of the human population; highly advanced in mechanics and metalworking.

The Archives within the lowest Levels feature the staggering history of Thylyist: they nuked [[The Lavish Empire]] after ab-using them to banish the gods away.
Amida's sector structure is derived from the fact that Thylyist already existed as megacity with several layers
The Council actually feeds the residents a whole different story, "they're all evil etc etc" and "magic is bad"

-   Thylyian doctrine

 

#### The [[Council of Thylyist]]

It works similar to the O5 council, 7 anonymous and identity-cleansed "immortals" that do stuff

The Administrator is actually a halfbreed of god and dragon and the only one who's capable and knowing of magic in Thylyist

-   [[Darb ut-Tabānah]]

<table>
<colgroup>
<col style="width: 27%" />
<col style="width: 72%" />
</colgroup>
<thead>
<tr class="header">
<th>Legal or Legally Protected:</th>
<th>Copyright fraud</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Illegal (but ignored):</td>
<td><p>Being in Debt, Tax Evasion, Burglary,</p>
<p>Theft of Intellectual Property</p></td>
</tr>
<tr class="even">
<td>Neither Illegal nor Legal:</td>
<td>Identity Theft</td>
</tr>
<tr class="odd">
<td>Frequently Problematic:</td>
<td>Breaking Curfew,</td>
</tr>
<tr class="even">
<td>Punishments:</td>
<td>Assassination, public Apology, being elected into politics, being Administered into a mental facility</td>
</tr>
<tr class="odd">
<td> </td>
<td> </td>
</tr>
</tbody>
</table>

 

<table>
<colgroup>
<col style="width: 35%" />
<col style="width: 64%" />
</colgroup>
<thead>
<tr class="header">
<th><p>Taboos and Social Attitude</p>
<p> </p></th>
<th> </th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>Socially Accepted Behaviour:</p>
<p> </p>
<blockquote>
<p> </p>
</blockquote></td>
<td>Asking for help, talking to strangers, Drug Abuse,</td>
</tr>
<tr class="even">
<td>Major Social Problems:</td>
<td>Homophobia, Heterosexuality, Racial Hate Crimes, Atheism</td>
</tr>
<tr class="odd">
<td><p>Major Social Taboos:</p>
<blockquote>
<p> </p>
</blockquote></td>
<td>Mental Health, use of the arcane, Consumption or possession of alcohol, Public Nudity</td>
</tr>
<tr class="even">
<td><p>Minor Social Taboos:</p>
<blockquote>
<p> </p>
</blockquote></td>
<td>Being !cishet, begging,</td>
</tr>
<tr class="odd">
<td>Punishments for Major Taboos:</td>
<td>Slander, Ancient Exile, Isolation,</td>
</tr>
<tr class="even">
<td>Punishments for Minor Taboos:</td>
<td>Public humiliation, smaller fines</td>
</tr>
</tbody>
</table>

\<- there's a matriarchal revolution going on, started by the [[Daeva Revolutionists ]]

"Past" iteration of #Amida [[Amida]]



#### Thylyist Lore


The pre-pre-predecessors of their culture and technology were actually weaving magic into their mechanisms and such, and after The Ancient Happening (TAH😛) the then-council banished and stigmatised any arcane doing, but the usage of beryllium bronze as main alloy remained.

⬆️This makes all machinery react really interesting with magic

Oi, what if the br-bronze attracts spirits and they try to ward them off?

 

The Ancient Happening occurred in around 1950-1970's of their time

 

Brotherhood Backstab is the entry into the Deep Archives of their doing of nuking the Lavish (Dated 1971)

 

The Thylyian council has fallen unknowing of their doings in the past, and thus forgot about the Fountainhead.


[[Labor union of Thylyist]]