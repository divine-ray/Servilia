#Thylyist #Thylyist-Military #locations 
The main stockpile of the Thylyian Military and Sentinels.

You should be really carefully here, they don't want anyone to see or know about this!

Headquarters to the Thylyian Military, and protected as such. 


 
**Threat Level: really fucking high**
	(**C**reatures-Traps-**E**nvironment)
		-   Suited Sentinels
		-   Off-Duty Soldiers
		-   Security Cameras
	**Possible Loot:**
		(**E**quipment-**V**aluables-**C**urrency)
			-   Sentinel Power Armour (Full Set, x4)
			-   Baton+4 (x10)
			-   Sentinel Half Mask (x20)
Location acquired from the Daeva or cradle.
