#Thylyist #Religion #locations  

The main religious building in [[City of Thylyist]], sainted to Gear and Cogwork.

Deep within and highly guarded, lies the Heart of Mekhane.

Massive building, towering over most Thylyian buildings, only competing to the Council Place and Octagate Rift Tower.
