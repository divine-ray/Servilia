#Areas #Northern-Reaches 
 These peaks seem to be haunted by poltergeists and memetic nightmares, but only during night. This may be a influence from the deviated sea. An above average occurrence of night runners have been spotted here¿¡
 

Almost identical to the surface traits of the Hollow Mountains:

-   Infested with night Runners

-   Multitude of sharp mountain peaks

-   Related to a supernatural being.

 

However, the [[Night Runner]] presence looms much stronger here, as no other force is governing them here.

They even seem to *seep* through the rock and stone... It cannot be healthy to stay here for longer..



Their strong presence here haunts any unsuspecting traveller, especially in their dreams.

 
