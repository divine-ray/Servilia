#Areas #Northern-Reaches 

Outside of the harsh rocks and ice, there is a far extending tundra, which is frozen with permafrost even in seemingly illogical stretches. The temperature there tends to vary per-region, and some lines tend to be notably colder. Based on the proximity to the [[Heart of Cold]], these temperature shifts might be effects of its accursed veins running below the surface.
