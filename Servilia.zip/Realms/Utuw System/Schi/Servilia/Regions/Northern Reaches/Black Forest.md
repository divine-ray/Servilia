
 

The colony of what little remains off the decimated plant life that once resided on the [[Northern Reaches]].

 

A dense and tightly standing forest of almost dwarf-like statues, shrunk in height, but strong on their trunk.

The canopy is very dense, depriving the forest floor of almost any light.

 

They're settled around the feet of the [[Alp Peaks]]. Mainly consisting of needle trees and being entangled with many (partly subterranean) rivers causes a high occurrence of deadwood and therefore drive a flourishing ecosphere of the extreme, for those that accustomed to the weather and cold.
