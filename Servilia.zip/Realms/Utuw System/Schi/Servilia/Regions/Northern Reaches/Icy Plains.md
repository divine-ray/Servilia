Icy Plains

Friday, 7. April 2023

09:52

 

The stretch where The Heart of Cold is situated.

These ice plains are constantly exposed to heavy storms and snowfall, which makes it a environment hazardous to any conventional life form.

A thick wall or fortification from rock, cliffs and ice looms around this slightly elevated area, fortifying it in addition to the the danger posed by glacial time.

 

This seems to have a reason.

The Heart of cold is in this area.

It's tainted veins burrowed themselves into Mother Gaia's flesh.

Leeching off warmth.

Causing all life to perish. Bringing cold. Bringing Death.

Yet... It lives. Brings its own life.

 
