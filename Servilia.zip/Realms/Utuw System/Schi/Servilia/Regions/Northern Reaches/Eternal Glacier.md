#Areas
This glacier poses a temporal anomaly, as anything within its area appears frozen to outside observers. Still, being a glacier, it grinds down its way, eventually into the ocean, where the anomalous effects begin to fade and eventually cease.

Nevertheless, a colossal spire of the hardest rock splits some arm or branch of the glacier, which shapes a massive ice plain, which isn't subjected to the glacial movement.
