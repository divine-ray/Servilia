Hollow Mountains

Monday, 25. April 2022

09:16

 

The Lavish got tasked by the Council of Thylyist and constructed the Fountainhead to generate the power required to terraform a whole chain of mountains.

 

 

The Lavish raised these mountains to a) encase the Ancient, and b) to expand their basin sea for a higher water level = more space for them.

 

The HM are Home to few night runners and hub for dragons

 

The inside is housing all kinds of underground critters, including dwarves

 

The hollow mountains got dug out by dwarfen miners tasked by The Council Of Thylyist in need of metals and resources.
