#Ancients #Areas 

Area where transcended humanoids reside after getting contained by the [[Fountainhead]] through [[The Lavish Empire]]. 

[[Hollow Mountains]]  were created as earthbound containment wall.

 

Three notable settlements:

-   Londo

-   Anor

-   New Londo

    -   Now ruined
