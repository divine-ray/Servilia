#Areas 
Remnants of the Betrayal, overgrown and renatured shrapnel and rubble, coagulated by earthen spirits, suspended  by gatherings of aer (air) spirits, who create massive updraft winds to keep their homes.

Well-protected by groups of [[Warped Angel|Angels]]. 

Habitat to many different spirits, whom the Ancients foster and care about.
[[Birth of Energy|Birthplace]] to manifested energies, who are aided by the midwife. 
