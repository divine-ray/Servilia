> Have you seen the [[Darb ut-Tabānah|old man]], in the closed-down market?
> Kicking up the paper, with his worn-out shoes?

( [[Londo]])




#TODO do this thingamajig

	 Have you seen the old man  
	In the closed down market  
	Kicking up the papers  
	With his worn out shoes?  
	In his eyes, you see no pride  
	Hand held loosely at his side  
	Yesterday's paper  
	Telling yesterday's news 
	  
	Have you seen the old girl  
	Who walks the streets of London  
	Dirt in her hair  
	And her clothes in rags?  
	  
	She's no time for talking  
	She just keeps right on walking  
	Carrying her home  
	In two carrier bags  
	  
	In the all night cafe  
	At a quarter past eleven  
	Same old man  
	Sitting there on his own  
	  
	Looking at the world  
	Over the rim of his tea cup  
	Each tea lasts an hour  
	And he wanders home alone  
	  
	Have you seen the old man  
	Outside the seaman's mission  
	Memory fading with  
	The medal ribbons that he wears?  
	  
	In our winter city  
	The rain cries a little pity  
	For one more forgotten hero  
	And a world that doesn't care  
	  
	So, how can you tell me you're lonely  
	And say for you that the sun don't shine?  
	Let me take you by the hand  
	And lead you through the streets of London  
	I'll show you something to make you change your mind