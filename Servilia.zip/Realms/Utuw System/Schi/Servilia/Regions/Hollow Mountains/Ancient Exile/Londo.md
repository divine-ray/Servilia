#Ancients #Settlements #ruins 
The once-former co-capital of the [[Ancient Exile]] and entryway to the [[Limbo Boneyard]].

It got overran and devastated by [[Vessels]] and [[Night Runner]]s in a dramatic raid that incapacitated and crippled a lot of [[Ancients]], including [[Darb ut-Tabānah]]. 