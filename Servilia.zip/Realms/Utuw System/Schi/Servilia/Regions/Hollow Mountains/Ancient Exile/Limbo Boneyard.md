#Ancients #Void 
 

A big storage pile of Vessel Masks, carved from celestial and draconic bones, sealed away and heavily protected.

The Ancient Deities amassed [[Vessel Mask]]s from failed or defeated [[Vessels]] to hinder the Void on affecting the material plane.

It's located below [[Londo]], dug by dwarves into the hollow mountains.

No one speaks about this, they either forgot or are too afraid of the word being spread.
At some point, information got leaked and [[The Void]] caused a massive raid upon [[Londo]] with all available forces, which led to the destruction of [[Londo]]. 
 

 

Now threatened by [[Warlock Gaíz-an]], who embarked on their quest to return the masks to the void.

 

### Location:
Below Londo.

### Dangerousness:

(**C**reatures-Traps-**E**nvironment)

-   3x "[[Warped Angel]]", anchor within the sealed space

-   No traps

-   Rifts in spacetime

 

#### Possible Loot:

(**E**quipment-**V**aluables-**C**urrency)

-   No Equip

-   Near-Infinite variety of Vessel Masks and Mask Shards

-   No Currency
