##  The undead City
#Undead #Settlements #Faction

The main settlement[^1] for victims of the [[Curse of the Undead]].

Only a smaller fraction of the residents voluntarily lives here, most of them got forcibly sent here.

It's underground, and they have a small religion going on, but it drifted too far into states that a alive and integer mind cannot parse.
*+1d4 insanity on inspect*
The main place of worship of their religion is said to be built atop a lich tomb, who has been cemented there before the Great Woe[^2]. 



Some of the residents are badly suffering from being [[Hollowed]]. The Hollowed are still treated with respect and care, similar to Alzheimer or dementia patients IRL.

Generally, the bearers that didn't loose it yet are partially depressed about the seemingly inevitable decay of their kin, and therefore see the contact to the Children of the Flame as revelation, as this saves their folk.

A brighter faction of them are using their pseudo eternal life to do what they never could've done, such as:

-   Bodily pleasures
-   "sinful" activities
-   Sex, drugs, rock and roll

However, this particular kind falls easily for hubris and is commonly detained (as those fall for hollowing quick).

[^1]: Rather a ghetto, but the feelings of understanding and community are attractive nevertheless.
[^2]: When Schi-Ut-Pula sold the world, causing the downfall of Death. 