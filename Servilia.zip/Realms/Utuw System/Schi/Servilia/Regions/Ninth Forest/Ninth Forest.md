
A wide-spanning forest ecosystem, including rainforest but also temperate to mediterranean plant life.

It's called the Ninth forest because it's on Number Nine if the Realm is abstracted onto the dial of a clock.

Central to it is the Green Swale of Seven (nine?) Spires.
