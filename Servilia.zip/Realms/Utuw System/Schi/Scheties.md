Gas Dwarf. 
three major moons
