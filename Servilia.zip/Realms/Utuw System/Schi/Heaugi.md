Moon of Schi. Tiny rocky core and mostly water and ice. 
A [[Lavish]] colony is suspected in these subsurface oceans.
It emits a significant impact on the twilight continuum of Schi.